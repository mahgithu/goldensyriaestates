import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { useNavigate, Link } from 'react-router-dom';
import { supabase } from '../lib/supabase';

export default function LoginPage() {
  const { isCloud, setCurrentUser, showToastMessage, users, setUsers } = useApp();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    if (isCloud) {
      const { data, error: authErr } = await supabase.auth.signInWithPassword({
        email,
        password
      });

      if (authErr) {
        setError(`خطأ في تسجيل الدخول: ${authErr.message}`);
        setLoading(false);
        return;
      }

      if (data.user) {
        const { data: profile } = await supabase
          .from('profiles')
          .select('*')
          .eq('id', data.user.id)
          .single();

        if (profile) {
          const normalizedProfile = {
            ...profile,
            role: email.toLowerCase() === 'admin@golden.sy' ? 'admin' : profile.role,
          };

          if (email.toLowerCase() === 'admin@golden.sy' && profile.role !== 'admin') {
            await supabase.from('profiles').update({ role: 'admin' }).eq('id', data.user.id);
          }

          setCurrentUser(normalizedProfile as any);
        } else {
          const adminUser = {
            id: data.user.id,
            name: email.split('@')[0],
            email: email,
            role: email.toLowerCase() === 'admin@golden.sy' ? 'admin' : 'user'
          };
          if (email.toLowerCase() === 'admin@golden.sy') {
            await supabase.from('profiles').upsert([adminUser]);
          }
          setCurrentUser(adminUser as any);
        }
        showToastMessage('مرحباً بك مجدداً في المنصة الذهبية! 🔑', 'success');
        navigate(email.toLowerCase() === 'admin@golden.sy' ? '/admin' : '/');
      }
    } else {
      // Offline fallback login simulation
      const found = users.find(u => u.email.toLowerCase() === email.toLowerCase());
      if (found) {
        if (found.banned) {
          setError('هذا الحساب محظور حالياً من قبل الإدارة.');
          setLoading(false);
          return;
        }
        setCurrentUser(found);
      } else {
      const newUser = {
        id: 'usr-' + Date.now(),
        name: email.split('@')[0],
        email,
        role: (email.toLowerCase() === 'admin@golden.sy' ? 'admin' : 'user') as 'admin' | 'user'
      };
      setUsers([newUser, ...users]);
      setCurrentUser(newUser);
    }
    showToastMessage('تم تسجيل الدخول بنجاح للوضع الفوري!', 'success');
    navigate(email.toLowerCase() === 'admin@golden.sy' ? '/admin' : '/');
  }
  setLoading(false);
};

  return (
    <div className="max-w-md mx-auto bg-zinc-900 border border-zinc-800 p-8 rounded-2xl text-right space-y-6 my-12" dir="rtl">
      <div className="text-center">
        <h1 className="text-2xl font-black text-transparent bg-clip-text bg-gradient-to-r from-white via-[#F3E5AB] to-[#C9A24A]">تسجيل دخول الأعضاء</h1>
        <p className="text-gray-400 text-xs mt-1">ادخل إلى حسابك السحابي لإدارة العقارات والسيارات وحفظ المفضلة</p>
      </div>

      {error && (
        <div className="p-3 bg-red-950/80 border border-red-900 text-red-200 rounded-lg text-xs font-bold text-center">
          ⚠️ {error}
        </div>
      )}

      <form onSubmit={handleLogin} className="space-y-4 text-xs">
        <div>
          <label className="block text-gray-400 mb-1">البريد الإلكتروني *</label>
          <input 
            type="email" 
            required 
            placeholder="مثال: name@gmail.com" 
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            className="w-full bg-black border border-zinc-700 rounded-xl p-3 text-white focus:border-[#C9A24A] focus:outline-none"
          />
        </div>

        <div>
          <label className="block text-gray-400 mb-1">كلمة المرور *</label>
          <input 
            type="password" 
            required 
            placeholder="أدخل كلمة المرور" 
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            className="w-full bg-black border border-zinc-700 rounded-xl p-3 text-white focus:border-[#C9A24A] focus:outline-none"
          />
        </div>

        <button 
          type="submit" 
          disabled={loading}
          className="w-full py-3 bg-[#C9A24A] hover:bg-[#E5BA5A] text-black font-extrabold rounded-xl transition-all shadow-lg text-xs cursor-pointer"
        >
          {loading ? 'جاري التحقق...' : 'تأكيد تسجيل الدخول 🔑'}
        </button>
      </form>

      <div className="pt-4 border-t border-zinc-800 text-center space-y-3">
        <p className="text-[11px] text-gray-400">ليس لديك حساب بعد؟ <Link to="/register" className="text-[#C9A24A] hover:underline">إنشاء حساب جديد مجاناً</Link></p>
      </div>
    </div>
  );
}
