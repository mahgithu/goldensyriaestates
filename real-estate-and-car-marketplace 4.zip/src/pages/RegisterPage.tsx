import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { useApp } from '../context/AppContext';
import { supabase } from '../lib/supabase';

export default function RegisterPage() {
  const { isCloud, setUsers, users, setCurrentUser, showToastMessage } = useApp();
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    if (!name || !email || !password) {
      setError('يرجى ملء جميع الحقول المطلوبة بالكامل.');
      setLoading(false);
      return;
    }

    if (isCloud) {
      const { data, error: authErr } = await supabase.auth.signUp({
        email,
        password,
        options: {
          data: { name }
        }
      });

      if (authErr) {
        setError(`خطأ أثناء إنشاء الحساب: ${authErr.message}`);
        setLoading(false);
        return;
      }

      if (data.user) {
        const newUser = {
          id: data.user.id,
          name,
          email,
          role: email.toLowerCase() === 'admin@golden.sy' ? ('admin' as const) : ('user' as const),
          is_agent: false
        };

        await supabase.from('profiles').insert([newUser]);
        setUsers([newUser, ...users]);
        setCurrentUser(newUser);
        showToastMessage('تم إنشاء حسابك الذهبي سحابياً بنجاح! 🎉', 'success');
        navigate('/');
      }
    } else {
      // Local register simulation
      const newUser = {
        id: 'usr-' + Date.now(),
        name,
        email,
        role: email.toLowerCase() === 'admin@golden.sy' ? ('admin' as const) : ('user' as const),
        is_agent: false
      };
      setUsers([newUser, ...users]);
      setCurrentUser(newUser);
      showToastMessage('تم إنشاء حسابك المحلي بنجاح!', 'success');
      navigate('/');
    }
    setLoading(false);
  };

  return (
    <div className="max-w-md mx-auto bg-zinc-900 border border-zinc-800 p-8 rounded-2xl text-right space-y-6 my-12" dir="rtl">
      <div className="text-center">
        <h1 className="text-2xl font-black text-transparent bg-clip-text bg-gradient-to-r from-white via-[#F3E5AB] to-[#C9A24A]">إنشاء حساب جديد</h1>
        <p className="text-gray-400 text-xs mt-1">سجل الآن مجاناً لنشر وحفظ عقاراتك وسياراتك لآلاف الزوار</p>
      </div>

      {error && (
        <div className="p-3 bg-red-950/80 border border-red-900 text-red-200 rounded-lg text-xs font-bold text-center">
          ⚠️ {error}
        </div>
      )}

      <form onSubmit={handleRegister} className="space-y-4 text-xs">
        <div>
          <label className="block text-gray-400 mb-1">الاسم الكامل *</label>
          <input 
            type="text" 
            required 
            placeholder="الاسم الحقيقي أو التجاري" 
            value={name}
            onChange={(e) => setName(e.target.value)}
            className="w-full bg-black border border-zinc-700 rounded-xl p-3 text-white focus:border-[#C9A24A] focus:outline-none"
          />
        </div>

        <div>
          <label className="block text-gray-400 mb-1">البريد الإلكتروني *</label>
          <input 
            type="email" 
            required 
            placeholder="example@domain.com" 
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            className="w-full bg-black border border-zinc-700 rounded-xl p-3 text-white focus:border-[#C9A24A] focus:outline-none"
          />
        </div>

        <div>
          <label className="block text-gray-400 mb-1">كلمة المرور *</label>
          <input 
            type="password" 
            required 
            placeholder="لا تقل عن 6 خانات" 
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            className="w-full bg-black border border-zinc-700 rounded-xl p-3 text-white focus:border-[#C9A24A] focus:outline-none"
          />
        </div>

        <button 
          type="submit" 
          disabled={loading}
          className="w-full py-3 bg-[#C9A24A] hover:bg-[#E5BA5A] text-black font-extrabold rounded-xl transition-all shadow-lg text-xs cursor-pointer"
        >
          {loading ? 'جاري التحميل...' : 'إنشاء حسابي الجديد 🎉'}
        </button>
      </form>

      <p className="text-xs text-gray-400 text-center">لديك حساب بالفعل؟ <Link to="/login" className="text-[#C9A24A] hover:underline">تسجيل الدخول من هنا</Link></p>
    </div>
  );
}
