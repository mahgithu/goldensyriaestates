import { useState } from 'react';
import { useApp } from '../context/AppContext';
import { supabase } from '../lib/supabase';
import { Link } from 'react-router-dom';

export default function ProfilePage() {
  const { currentUser, setCurrentUser, isCloud, showToastMessage } = useApp();
  const [name, setName] = useState(currentUser?.name || '');
  const [company, setCompany] = useState(currentUser?.agent_company || '');
  const [phone, setPhone] = useState(currentUser?.agent_phone || '');

  if (!currentUser) {
    return (
      <div className="text-center py-16">
        <p className="text-gray-400 text-sm">يجب تسجيل الدخول أولاً لتتمكن من تعديل حسابك الشخصي ⚠️</p>
      </div>
    );
  }

  const handleUpdateProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;

    const updatedUser = {
      ...currentUser,
      name,
      agent_company: company,
      agent_phone: phone,
    };

    setCurrentUser(updatedUser);

    if (isCloud) {
      await supabase.from('profiles').update({
        name,
        agent_company: company,
        agent_phone: phone,
      }).eq('id', currentUser.id);
    }

    showToastMessage('تم تحديث ملفك التعريفي بنجاح! 💾', 'success');
  };

  return (
    <div className="space-y-8 max-w-4xl mx-auto text-right">
      {currentUser.role === 'admin' && (
        <div className="bg-gradient-to-r from-amber-950/20 via-black to-zinc-950 p-5 rounded-2xl border border-[#C9A24A]/30 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div>
            <h2 className="text-lg font-black text-[#C9A24A]">👑 أنت المدير المطلق للمنصة</h2>
            <p className="text-gray-400 text-xs mt-1">يمكنك الانتقال إلى لوحة الإدارة للتحكم الكامل بالوكلاء.</p>
          </div>
          <Link to="/admin" className="px-5 py-2.5 bg-[#C9A24A] text-black font-extrabold rounded-xl text-xs">
            فتح لوحة الإدارة
          </Link>
        </div>
      )}

      <div className="bg-zinc-900 border border-zinc-800 p-6 rounded-2xl space-y-6">
        <div>
          <h1 className="text-xl font-black text-white">👤 إعدادات حسابك الشخصي والوكالة</h1>
          <p className="text-gray-400 text-xs mt-1">قم بتعديل اسمك وهاتفك وسيكون ظاهراً لجميع عملاء العقارات والسيارات</p>
        </div>

        <form onSubmit={handleUpdateProfile} className="space-y-4 text-xs">
          <div>
            <label className="block text-gray-400 mb-1">الاسم بالكامل *</label>
            <input
              type="text"
              required
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="w-full bg-black border border-zinc-800 rounded-lg p-2.5 text-white"
            />
          </div>

          <div>
            <label className="block text-gray-400 mb-1">البريد الإلكتروني (غير قابل للتعديل)</label>
            <input
              type="email"
              disabled
              value={currentUser.email}
              className="w-full bg-zinc-800/50 border border-zinc-800 rounded-lg p-2.5 text-gray-500 cursor-not-allowed"
            />
          </div>

          <div>
            <label className="block text-gray-400 mb-1">رقم الهاتف للتواصل</label>
            <input
              type="text"
              value={phone}
              onChange={(e) => setPhone(e.target.value)}
              className="w-full bg-black border border-zinc-800 rounded-lg p-2.5 text-white"
              placeholder="مثال: 0944111222"
            />
          </div>

          {currentUser.is_agent && (
            <div>
              <label className="block text-gray-400 mb-1">نوع العمل / اسم الوكالة</label>
              <input
                type="text"
                value={company}
                onChange={(e) => setCompany(e.target.value)}
                className="w-full bg-black border border-zinc-800 rounded-lg p-2.5 text-white"
                placeholder="مثال: وسيط عقاري / مكتب الياسمين العقاري"
              />
            </div>
          )}

          <button type="submit" className="w-full py-2.5 bg-[#C9A24A] text-black font-extrabold rounded-lg">
            حفظ التغييرات 💾
          </button>
        </form>
      </div>
    </div>
  );
}
