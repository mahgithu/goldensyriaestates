import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useApp } from '../context/AppContext';
import { supabase, uploadImageToSupabase } from '../lib/supabase';
import { FileImage, CheckCircle, AlertCircle, Trash2, ArrowLeft, ArrowRight, Sparkles } from 'lucide-react';

interface PropertyFormData {
  title: string;
  price: number;
  price_usd: number;
  city: string;
  description: string;
  image: string;
  type: 'شقة' | 'فيلا' | 'أرض' | 'محل';
  user_phone: string;
  area: number;
  rooms: number;
}

interface CarFormData {
  title: string;
  name: string;
  model: string;
  price: number;
  price_usd: number;
  city: string;
  description: string;
  image: string;
  user_phone: string;
  year: string;
}

export default function AddListingPage() {
  const { isCloud, currentUser, showToastMessage, properties, setProperties, cars, setCars } = useApp();
  const navigate = useNavigate();

  // Listing category selection: 'property' or 'car'
  const [category, setCategory] = useState<'property' | 'car'>('property');
  const [step, setStep] = useState<number>(1);
  const [loading, setLoading] = useState<boolean>(false);
  const [errorMsg, setErrorMsg] = useState<string>('');
  
  // Custom uploaded images state with progress
  const [uploadedImages, setUploadedImages] = useState<string[]>([]);
  const [uploadProgress, setUploadProgress] = useState<number>(0);

  // Form State for Property
  const [propForm, setPropForm] = useState<PropertyFormData>({
    title: '',
    price: 150000000,
    price_usd: 12000,
    city: 'دمشق',
    type: 'شقة',
    area: 120,
    rooms: 3,
    user_phone: '0944111222',
    description: '',
    image: 'https://images.pexels.com/photos/10647324/pexels-photo-10647324.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200'
  });

  // Form State for Car
  const [carForm, setCarForm] = useState<CarFormData>({
    title: '',
    name: 'BMW',
    model: 'X6 M50i',
    price: 250000000,
    price_usd: 18000,
    city: 'دمشق',
    year: '2024',
    user_phone: '0955111222',
    description: '',
    image: 'https://images.pexels.com/photos/14165943/pexels-photo-14165943.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200'
  });

  // 1. Auto-Save Draft Progress from LocalStorage (Draft Purposes Only)
  useEffect(() => {
    const savedDraftType = localStorage.getItem('sy_gold_draft_type');
    if (savedDraftType) {
      setCategory(savedDraftType as 'property' | 'car');
    }

    const savedPropDraft = localStorage.getItem('sy_gold_draft_property');
    if (savedPropDraft) {
      try { setPropForm(JSON.parse(savedPropDraft)); } catch (e) { console.error(e); }
    }

    const savedCarDraft = localStorage.getItem('sy_gold_draft_car');
    if (savedCarDraft) {
      try { setCarForm(JSON.parse(savedCarDraft)); } catch (e) { console.error(e); }
    }
  }, []);

  // Save drafts as user types
  const savePropertyDraft = (updated: PropertyFormData) => {
    setPropForm(updated);
    localStorage.setItem('sy_gold_draft_property', JSON.stringify(updated));
    localStorage.setItem('sy_gold_draft_type', 'property');
  };

  const saveCarDraft = (updated: CarFormData) => {
    setCarForm(updated);
    localStorage.setItem('sy_gold_draft_car', JSON.stringify(updated));
    localStorage.setItem('sy_gold_draft_type', 'car');
  };

  const clearDraft = () => {
    localStorage.removeItem('sy_gold_draft_property');
    localStorage.removeItem('sy_gold_draft_car');
    localStorage.removeItem('sy_gold_draft_type');
  };

  // 2. Drag & Drop or Custom Multi Image file uploading
  const handleMultipleFiles = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files) return;

    setErrorMsg('');
    setUploadProgress(10);
    
    // Simulate image optimization and compression
    const readerPromises = Array.from(files).map((file) => {
      // Validate file size (max 5MB)
      if (file.size > 5 * 1024 * 1024) {
        setErrorMsg('حجم إحدى الصور كبير جداً، يرجى رفع صور أقل من 5 ميغابايت.');
        return Promise.resolve(null);
      }
      // Validate file type (images only)
      if (!file.type.startsWith('image/')) {
        setErrorMsg('يرجى اختيار ملفات صور صالحة فقط.');
        return Promise.resolve(null);
      }

      return new Promise<string | null>((resolve) => {
        const reader = new FileReader();
        reader.onloadend = () => {
          resolve(reader.result as string);
        };
        reader.readAsDataURL(file);
      });
    });

    setUploadProgress(40);
    Promise.all(readerPromises).then((results) => {
      const validResults = results.filter((r): r is string => r !== null);
      if (validResults.length > 0) {
        const updatedImages = [...uploadedImages, ...validResults];
        setUploadedImages(updatedImages);
        
        // Update first image as main cover
        if (category === 'property') {
          savePropertyDraft({ ...propForm, image: validResults[0] });
        } else {
          saveCarDraft({ ...carForm, image: validResults[0] });
        }
        showToastMessage('تم ضغط وتحميل الصور بنجاح ومعاينتها جاهزة للخطوة التالية!', 'success');
      }
      setUploadProgress(100);
      setTimeout(() => setUploadProgress(0), 1000);
    });
  };

  // Remove uploaded image from step 3 list
  const handleRemoveImage = (indexToRemove: number) => {
    const updated = uploadedImages.filter((_, idx) => idx !== indexToRemove);
    setUploadedImages(updated);
    if (updated.length > 0) {
      if (category === 'property') {
        savePropertyDraft({ ...propForm, image: updated[0] });
      } else {
        saveCarDraft({ ...carForm, image: updated[0] });
      }
    }
    showToastMessage('تم حذف الصورة المحددة بنجاح', 'info');
  };

  // 3. Wizard Step Validation before proceeding
  const handleNextStep = () => {
    setErrorMsg('');
    if (step === 1) {
      if (category === 'property') {
        if (!propForm.title.trim() || propForm.title.length < 5) {
          setErrorMsg('يرجى كتابة عنوان جذاب ومفهوم للعقار لا يقل عن 5 أحرف.');
          return;
        }
        if (!propForm.description.trim() || propForm.description.length < 10) {
          setErrorMsg('يرجى تقديم وصف تفصيلي واضح لا يقل عن 10 أحرف.');
          return;
        }
      } else {
        if (!carForm.title.trim() || carForm.title.length < 5) {
          setErrorMsg('يرجى كتابة عنوان مناسب للسيارة.');
          return;
        }
        if (!carForm.description.trim() || carForm.description.length < 10) {
          setErrorMsg('يرجى تقديم وصف تفصيلي لحالة السيارة الفنية.');
          return;
        }
      }
    }

    if (step === 2) {
      if (category === 'property') {
        if (propForm.price <= 0 || propForm.price_usd <= 0) {
          setErrorMsg('يرجى إدخال السعر الصحيح بالدولار وبالليرة السورية.');
          return;
        }
        if (!propForm.user_phone.trim()) {
          setErrorMsg('رقم التواصل مطلوب.');
          return;
        }
      } else {
        if (carForm.price <= 0 || carForm.price_usd <= 0) {
          setErrorMsg('يرجى إدخال سعر صحيح للسيارة.');
          return;
        }
        if (!carForm.user_phone.trim()) {
          setErrorMsg('رقم الهاتف للتواصل مطلوب.');
          return;
        }
      }
    }

    if (step === 3) {
      if (uploadedImages.length === 0) {
        setErrorMsg('يرجى رفع صورة واحدة على الأقل لعقارك أو سيارتك لجذب المشترين.');
        return;
      }
    }

    setStep(prev => prev + 1);
  };

  // 4. Final Submission & Storage Linkage
  const handlePublishListing = async () => {
    if (!currentUser) {
      showToastMessage('يرجى تسجيل الدخول أولاً لتتمكن من النشر!', 'error');
      navigate('/login');
      return;
    }

    setLoading(true);
    setErrorMsg('');

    try {
      if (category === 'property') {
        // Upload images one by one (simulated or real storage)
        let finalMainImage = propForm.image;
        if (uploadedImages.length > 0) {
          // Use the uploaded Base64 directly or upload to Supabase Storage if configured
          const uploadedUrl = await uploadImageToSupabase(uploadedImages[0], 'images');
          finalMainImage = uploadedUrl;
        }

        const newProp = {
          id: 'prop-' + Date.now(),
          title: propForm.title,
          price: Number(propForm.price),
          price_usd: Number(propForm.price_usd),
          city: propForm.city,
          description: propForm.description,
          image: finalMainImage,
          type: propForm.type,
          user_id: currentUser.id,
          user_phone: propForm.user_phone,
          area: Number(propForm.area),
          rooms: Number(propForm.rooms),
          created_at: new Date().toISOString()
        };

        if (isCloud) {
          await supabase.from('properties').insert([newProp]);
        }
        
        setProperties([newProp, ...properties]);
        showToastMessage('تم حفظ ونشر عقارك السحابي الذهبي بنجاح تام وهو مرئي الآن للجميع! 🏢', 'success');

      } else {
        let finalCarImage = carForm.image;
        if (uploadedImages.length > 0) {
          const uploadedUrl = await uploadImageToSupabase(uploadedImages[0], 'images');
          finalCarImage = uploadedUrl;
        }

        const newCar = {
          id: 'car-' + Date.now(),
          title: carForm.title,
          name: carForm.name,
          model: carForm.model,
          price: Number(carForm.price),
          price_usd: Number(carForm.price_usd),
          city: carForm.city,
          description: carForm.description,
          image: finalCarImage,
          user_id: currentUser.id,
          user_phone: carForm.user_phone,
          year: carForm.year,
          created_at: new Date().toISOString()
        };

        if (isCloud) {
          await supabase.from('cars').insert([newCar]);
        }

        setCars([newCar, ...cars]);
        showToastMessage('تم حفظ ونشر سيارتك بالمعرض لتظهر لجميع الزوار على الفور! 🚗', 'success');
      }

      clearDraft();
      navigate(category === 'property' ? '/properties' : '/cars');

    } catch (err: any) {
      console.error(err);
      setErrorMsg(`حدث خطأ أثناء الاتصال وحفظ البيانات: ${err?.message || 'يرجى المحاولة مجدداً.'}`);
    } finally {
      setLoading(false);
    }
  };

  const SYRIAN_CITIES = ['دمشق', 'ريف دمشق', 'حلب', 'حمص', 'اللاذقية', 'طرطوس', 'حماة', 'السويداء'];
  const PROPERTY_TYPES = ['شقة', 'فيلا', 'أرض', 'محل'];

  return (
    <div className="max-w-3xl mx-auto space-y-8 text-right p-2 sm:p-6" dir="rtl">
      
      {/* Back Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-zinc-800 pb-4">
        <div>
          <h1 className="text-2xl font-black text-transparent bg-clip-text bg-gradient-to-r from-white via-[#F3E5AB] to-[#C9A24A] flex items-center gap-2">
            <Sparkles className="h-5 w-5 text-gold shrink-0" />
            <span>نشر إعلان ذهبي جديد بالصور</span>
          </h1>
          <p className="text-gray-400 text-xs mt-1">النموذج المتطور على خطوات - متاح للجميع بالدولار والليرة</p>
        </div>

        {/* Draft Notification Indicator */}
        <span className="text-[11px] bg-gold/10 text-gold px-3 py-1 rounded-full border border-gold/20 font-bold self-start sm:self-auto">
          ✏️ يتم الحفظ كمسودة تلقائية
        </span>
      </div>

      {/* Progress Wizard Steps */}
      <div className="grid grid-cols-4 gap-2 text-center text-[10px] sm:text-xs bg-zinc-900 p-3 rounded-xl border border-zinc-800 font-bold">
        <div className={`p-2 rounded-lg transition-all ${step === 1 ? 'bg-gold text-black font-black' : 'text-gray-400'}`}>1. المعلومات العامة</div>
        <div className={`p-2 rounded-lg transition-all ${step === 2 ? 'bg-gold text-black font-black' : 'text-gray-400'}`}>2. الموقع والسعر</div>
        <div className={`p-2 rounded-lg transition-all ${step === 3 ? 'bg-gold text-black font-black' : 'text-gray-400'}`}>3. رفع الصور</div>
        <div className={`p-2 rounded-lg transition-all ${step === 4 ? 'bg-gold text-black font-black' : 'text-gray-400'}`}>4. المراجعة والنشر</div>
      </div>

      {errorMsg && (
        <div className="p-3.5 bg-red-950/80 border border-red-900 rounded-xl text-red-200 text-xs font-bold flex items-center gap-2">
          <AlertCircle className="h-4 w-4 shrink-0 text-red-400" />
          <span>{errorMsg}</span>
        </div>
      )}

      {/* STEP 1: Basic Choice & Details */}
      {step === 1 && (
        <div className="bg-zinc-900 p-6 rounded-2xl border border-zinc-800 space-y-6">
          <div className="space-y-2">
            <label className="block text-xs font-bold text-gray-300">أولاً، حدد تصنيف الإعلان الأساسي: *</label>
            <div className="grid grid-cols-2 gap-4">
              <button
                type="button"
                onClick={() => { setCategory('property'); localStorage.setItem('sy_gold_draft_type', 'property'); }}
                className={`py-3.5 rounded-xl border font-black transition-all text-xs cursor-pointer ${category === 'property' ? 'bg-gold text-black border-gold shadow-lg' : 'bg-black text-gray-400 border-zinc-800 hover:border-zinc-700'}`}
              >
                🏢 عقار (شقة، فيلا، أرض، محل)
              </button>
              <button
                type="button"
                onClick={() => { setCategory('car'); localStorage.setItem('sy_gold_draft_type', 'car'); }}
                className={`py-3.5 rounded-xl border font-black transition-all text-xs cursor-pointer ${category === 'car' ? 'bg-gold text-black border-gold shadow-lg' : 'bg-black text-gray-400 border-zinc-800 hover:border-zinc-700'}`}
              >
                🚗 سيارة فاخرة بالمعرض
              </button>
            </div>
          </div>

          {category === 'property' ? (
            <div className="space-y-4">
              <div>
                <label className="block text-xs text-gray-400 mb-1">عنوان العقار للإعلان *</label>
                <input 
                  type="text" 
                  value={propForm.title} 
                  onChange={(e) => savePropertyDraft({ ...propForm, title: e.target.value })}
                  placeholder="مثال: فيلا ملكية ديلوكس مع مسبح خاص في يعفور" 
                  className="w-full bg-black border border-zinc-700 rounded-xl p-3 text-xs text-white focus:border-[#C9A24A] focus:outline-none"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs text-gray-400 mb-1">نوع العقار *</label>
                  <select 
                    value={propForm.type} 
                    onChange={(e) => savePropertyDraft({ ...propForm, type: e.target.value as any })}
                    className="w-full bg-black border border-zinc-700 rounded-xl p-3 text-xs text-white"
                  >
                    {PROPERTY_TYPES.map(t => <option key={t} value={t}>{t}</option>)}
                  </select>
                </div>
                <div>
                  <label className="block text-xs text-gray-400 mb-1">عدد الغرف *</label>
                  <input 
                    type="number" 
                    value={propForm.rooms} 
                    onChange={(e) => savePropertyDraft({ ...propForm, rooms: Number(e.target.value) })}
                    className="w-full bg-black border border-zinc-700 rounded-xl p-3 text-xs text-white"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs text-gray-400 mb-1">الوصف التفصيلي والمميزات الكسوة *</label>
                <textarea 
                  rows={4} 
                  value={propForm.description} 
                  onChange={(e) => savePropertyDraft({ ...propForm, description: e.target.value })}
                  placeholder="اكتب هنا مواصفات البناء، المصعد، طاقة شمسية، كسوة سوبر ديلوكس..." 
                  className="w-full bg-black border border-zinc-700 rounded-xl p-3 text-xs text-white focus:outline-none"
                />
              </div>
            </div>
          ) : (
            <div className="space-y-4">
              <div>
                <label className="block text-xs text-gray-400 mb-1">عنوان الإعلان للسيارة *</label>
                <input 
                  type="text" 
                  value={carForm.title} 
                  onChange={(e) => saveCarDraft({ ...carForm, title: e.target.value })}
                  placeholder="مثال: بي إم دبليو X6 فل مواصفات موديل ٢٠٢٤ بحالة الوكالة" 
                  className="w-full bg-black border border-zinc-700 rounded-xl p-3 text-xs text-white focus:border-[#C9A24A] focus:outline-none"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs text-gray-400 mb-1">الشركة المصنعة (الماركة) *</label>
                  <input 
                    type="text" 
                    value={carForm.name} 
                    onChange={(e) => saveCarDraft({ ...carForm, name: e.target.value })}
                    placeholder="مثال: Mercedes-Benz" 
                    className="w-full bg-black border border-zinc-700 rounded-xl p-3 text-xs text-white"
                  />
                </div>
                <div>
                  <label className="block text-xs text-gray-400 mb-1">الفئة / الموديل بالتحديد *</label>
                  <input 
                    type="text" 
                    value={carForm.model} 
                    onChange={(e) => saveCarDraft({ ...carForm, model: e.target.value })}
                    placeholder="S500 AMG" 
                    className="w-full bg-black border border-zinc-700 rounded-xl p-3 text-xs text-white"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs text-gray-400 mb-1">المواصفات والحالة الفنية *</label>
                <textarea 
                  rows={4} 
                  value={carForm.description} 
                  onChange={(e) => saveCarDraft({ ...carForm, description: e.target.value })}
                  placeholder="اكتب تفاصيل المحرك، حالة الدهان، خالية من العلامات أو القطع المبدلة..." 
                  className="w-full bg-black border border-zinc-700 rounded-xl p-3 text-xs text-white focus:outline-none"
                />
              </div>
            </div>
          )}

          <div className="flex justify-end pt-2">
            <button
              type="button"
              onClick={handleNextStep}
              className="px-6 py-2.5 bg-[#C9A24A] hover:bg-[#E5BA5A] text-black font-bold text-xs rounded-xl flex items-center gap-1 cursor-pointer"
            >
              <span>الذهاب للخطوة التالية</span>
              <ArrowLeft className="h-4 w-4" />
            </button>
          </div>
        </div>
      )}

      {/* STEP 2: Location & Price with both Currencies */}
      {step === 2 && (
        <div className="bg-zinc-900 p-6 rounded-2xl border border-zinc-800 space-y-6">
          <h3 className="font-bold text-white text-sm text-gold">الموقع، العملة والأسعار المزدوجة</h3>
          <p className="text-gray-400 text-xs">ندعم إظهار الأسعار بالعملة السورية والدولار لتسهيل التقييم.</p>

          {category === 'property' ? (
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs text-gray-400 mb-1">السعر بالليرة السورية (ل.س) *</label>
                  <input 
                    type="number" 
                    value={propForm.price} 
                    onChange={(e) => savePropertyDraft({ ...propForm, price: Number(e.target.value) })}
                    className="w-full bg-black border border-zinc-700 rounded-xl p-3 text-xs text-white"
                  />
                  <span className="text-[10px] text-gray-500 block mt-1">{propForm.price.toLocaleString()} ليرة سورية</span>
                </div>
                <div>
                  <label className="block text-xs text-gray-400 mb-1">السعر بالدولار الأمريكي ($) *</label>
                  <input 
                    type="number" 
                    value={propForm.price_usd} 
                    onChange={(e) => savePropertyDraft({ ...propForm, price_usd: Number(e.target.value) })}
                    className="w-full bg-black border border-zinc-700 rounded-xl p-3 text-xs text-white"
                  />
                  <span className="text-[10px] text-amber-400 block mt-1">${propForm.price_usd.toLocaleString()} دولار</span>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs text-gray-400 mb-1">المحافظة / المدينة *</label>
                  <select 
                    value={propForm.city} 
                    onChange={(e) => savePropertyDraft({ ...propForm, city: e.target.value })}
                    className="w-full bg-black border border-zinc-700 rounded-xl p-3 text-xs text-white"
                  >
                    {SYRIAN_CITIES.map(c => <option key={c} value={c}>{c}</option>)}
                  </select>
                </div>
                <div>
                  <label className="block text-xs text-gray-400 mb-1">المساحة الإجمالية (م²) *</label>
                  <input 
                    type="number" 
                    value={propForm.area} 
                    onChange={(e) => savePropertyDraft({ ...propForm, area: Number(e.target.value) })}
                    className="w-full bg-black border border-zinc-700 rounded-xl p-3 text-xs text-white"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs text-gray-400 mb-1">رقم تواصل العميل والواتساب المعتمد *</label>
                <input 
                  type="text" 
                  value={propForm.user_phone} 
                  onChange={(e) => savePropertyDraft({ ...propForm, user_phone: e.target.value })}
                  placeholder="مثال: 0944111222"
                  className="w-full bg-black border border-zinc-700 rounded-xl p-3 text-xs text-white"
                />
              </div>
            </div>
          ) : (
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs text-gray-400 mb-1">السعر بالليرة السورية (ل.س) *</label>
                  <input 
                    type="number" 
                    value={carForm.price} 
                    onChange={(e) => saveCarDraft({ ...carForm, price: Number(e.target.value) })}
                    className="w-full bg-black border border-zinc-700 rounded-xl p-3 text-xs text-white"
                  />
                  <span className="text-[10px] text-gray-500 block mt-1">{carForm.price.toLocaleString()} ليرة سورية</span>
                </div>
                <div>
                  <label className="block text-xs text-gray-400 mb-1">السعر بالدولار الأمريكي ($) *</label>
                  <input 
                    type="number" 
                    value={carForm.price_usd} 
                    onChange={(e) => saveCarDraft({ ...carForm, price_usd: Number(e.target.value) })}
                    className="w-full bg-black border border-zinc-700 rounded-xl p-3 text-xs text-white"
                  />
                  <span className="text-[10px] text-amber-400 block mt-1">${carForm.price_usd.toLocaleString()} دولار</span>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs text-gray-400 mb-1">مكان وجود السيارة *</label>
                  <select 
                    value={carForm.city} 
                    onChange={(e) => saveCarDraft({ ...carForm, city: e.target.value })}
                    className="w-full bg-black border border-zinc-700 rounded-xl p-3 text-xs text-white"
                  >
                    {SYRIAN_CITIES.map(c => <option key={c} value={c}>{c}</option>)}
                  </select>
                </div>
                <div>
                  <label className="block text-xs text-gray-400 mb-1">سنة الصنع *</label>
                  <input 
                    type="text" 
                    value={carForm.year} 
                    onChange={(e) => saveCarDraft({ ...carForm, year: e.target.value })}
                    placeholder="2024"
                    className="w-full bg-black border border-zinc-700 rounded-xl p-3 text-xs text-white"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs text-gray-400 mb-1">رقم تواصل العميل والواتساب *</label>
                <input 
                  type="text" 
                  value={carForm.user_phone} 
                  onChange={(e) => saveCarDraft({ ...carForm, user_phone: e.target.value })}
                  placeholder="0955111222"
                  className="w-full bg-black border border-zinc-700 rounded-xl p-3 text-xs text-white"
                />
              </div>
            </div>
          )}

          <div className="flex justify-between pt-2">
            <button
              type="button"
              onClick={() => setStep(1)}
              className="px-4 py-2.5 bg-zinc-800 text-gray-300 hover:text-white rounded-xl text-xs flex items-center gap-1 cursor-pointer"
            >
              <ArrowRight className="h-4 w-4" />
              <span>السابق</span>
            </button>
            <button
              type="button"
              onClick={handleNextStep}
              className="px-6 py-2.5 bg-[#C9A24A] hover:bg-[#E5BA5A] text-black font-bold text-xs rounded-xl flex items-center gap-1 cursor-pointer"
            >
              <span>الذهاب للخطوة التالية</span>
              <ArrowLeft className="h-4 w-4" />
            </button>
          </div>
        </div>
      )}

      {/* STEP 3: Multiple Images Upload */}
      {step === 3 && (
        <div className="bg-zinc-900 p-6 rounded-2xl border border-zinc-800 space-y-6">
          <h3 className="font-bold text-white text-sm text-gold">رفع صور الإعلان بشكل احترافي</h3>
          <p className="text-gray-400 text-xs">ارفع صوراً حقيقية من هاتفك أو لابتوبك فوراً. الصور تمنح إعلانك ثقة تامة ومبيعات أسرع.</p>

          {/* DRAG & DROP ZONE */}
          <div className="border-2 border-dashed border-[#C9A24A]/40 rounded-xl p-8 text-center bg-black/40 hover:bg-black/60 transition-colors relative cursor-pointer">
            <input 
              type="file" 
              multiple 
              accept="image/*"
              onChange={handleMultipleFiles}
              className="absolute inset-0 opacity-0 cursor-pointer" 
            />
            <FileImage className="h-10 w-10 text-[#C9A24A] mx-auto mb-2" />
            <p className="text-xs font-bold text-white">انقر هنا أو اسحب صور عقارك أو سيارتك للرفع</p>
            <p className="text-[10px] text-gray-500 mt-1">يمكنك اختيار ملفات متعددة (JPEG, PNG, JPG) بحد أقصى 5 ميغابايت لكل صورة.</p>
          </div>

          {/* UPLOAD PROGRESS BAR */}
          {uploadProgress > 0 && (
            <div className="space-y-1 text-center">
              <p className="text-[10px] text-[#C9A24A]">جاري معالجة الصور وضغطها بنسبة... {uploadProgress}%</p>
              <div className="w-full bg-zinc-800 h-1.5 rounded-full overflow-hidden">
                <div className="bg-[#C9A24A] h-full" style={{ width: `${uploadProgress}%` }}></div>
              </div>
            </div>
          )}

          {/* PREVIEWS & REMOVE ACTIONS */}
          {uploadedImages.length > 0 && (
            <div className="space-y-2">
              <p className="text-xs text-gray-400 font-bold">الصور المرفوعة حالياً ({uploadedImages.length}):</p>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                {uploadedImages.map((img, idx) => (
                  <div key={idx} className="relative rounded-lg overflow-hidden group border border-zinc-800 bg-black">
                    <img src={img} className="h-24 w-full object-cover" />
                    <div className="absolute top-1 left-1">
                      <button
                        type="button"
                        onClick={() => handleRemoveImage(idx)}
                        className="p-1 bg-red-900/90 text-white rounded hover:bg-red-700 transition-colors"
                        title="حذف الصورة"
                      >
                        <Trash2 className="h-3 w-3" />
                      </button>
                    </div>
                    {idx === 0 && (
                      <span className="absolute bottom-1 right-1 bg-gold text-black font-black text-[8px] px-1.5 rounded">الصورة الرئيسية</span>
                    )}
                  </div>
                ))}
              </div>
            </div>
          )}

          <div className="flex justify-between pt-2">
            <button
              type="button"
              onClick={() => setStep(2)}
              className="px-4 py-2.5 bg-zinc-800 text-gray-300 hover:text-white rounded-xl text-xs flex items-center gap-1 cursor-pointer"
            >
              <ArrowRight className="h-4 w-4" />
              <span>السابق</span>
            </button>
            <button
              type="button"
              onClick={handleNextStep}
              className="px-6 py-2.5 bg-[#C9A24A] hover:bg-[#E5BA5A] text-black font-bold text-xs rounded-xl flex items-center gap-1 cursor-pointer"
            >
              <span>الذهاب للمراجعة النهائية</span>
              <ArrowLeft className="h-4 w-4" />
            </button>
          </div>
        </div>
      )}

      {/* STEP 4: Review and Publish */}
      {step === 4 && (
        <div className="bg-zinc-900 p-6 rounded-2xl border border-zinc-800 space-y-6">
          <div className="border-b border-zinc-800 pb-3">
            <h3 className="font-bold text-white text-sm text-gold">الخطوة الأخيرة: مراجعة نهائية للإعلان قبل النشر</h3>
            <p className="text-gray-400 text-xs">يرجى التأكد من صحة الأسعار بالدولار وبالليرة السورية وموقع العقار.</p>
          </div>

          {category === 'property' ? (
            <div className="space-y-4">
              <div className="p-4 bg-black/40 rounded-xl space-y-2">
                <p className="text-xs text-gray-400">تصنيف الإعلان: <strong className="text-white">عقارات 🏢 ({propForm.type})</strong></p>
                <p className="text-xs text-gray-400">عنوان الإعلان: <strong className="text-white text-sm">{propForm.title}</strong></p>
                <p className="text-xs text-gray-400">المدينة / المحافظة: <strong className="text-white">{propForm.city}</strong></p>
                <p className="text-xs text-gray-400">السعر السنوي بالعملة السورية: <strong className="text-[#C9A24A]">{propForm.price.toLocaleString()} ل.س</strong></p>
                <p className="text-xs text-gray-400">السعر بالدولار الأمريكي: <strong className="text-emerald-400">${propForm.price_usd.toLocaleString()}</strong></p>
                <p className="text-xs text-gray-400">رقم التواصل المعتمد: <strong className="text-white">{propForm.user_phone}</strong></p>
                <p className="text-xs text-gray-400">الوصف العام: <p className="text-gray-300 mt-1 whitespace-pre-wrap">{propForm.description}</p></p>
              </div>
            </div>
          ) : (
            <div className="space-y-4">
              <div className="p-4 bg-black/40 rounded-xl space-y-2">
                <p className="text-xs text-gray-400">تصنيف الإعلان: <strong className="text-white">سيارات 🚗 ({carForm.name})</strong></p>
                <p className="text-xs text-gray-400">عنوان الإعلان: <strong className="text-white text-sm">{carForm.title}</strong></p>
                <p className="text-xs text-gray-400">الفئة والموديل: <strong className="text-[#C9A24A]">{carForm.model} - سنة الصنع {carForm.year}</strong></p>
                <p className="text-xs text-gray-400">السعر بالليرة السورية: <strong className="text-[#C9A24A]">{carForm.price.toLocaleString()} ل.س</strong></p>
                <p className="text-xs text-gray-400">السعر بالدولار الأمريكي: <strong className="text-emerald-400">${carForm.price_usd.toLocaleString()}</strong></p>
                <p className="text-xs text-gray-400">الوصف والحالة الفنية: <p className="text-gray-300 mt-1 whitespace-pre-wrap">{carForm.description}</p></p>
              </div>
            </div>
          )}

          {/* Loading Indicator */}
          {loading && (
            <div className="p-3 bg-[#C9A24A]/10 border border-[#C9A24A] rounded-xl text-center text-[#C9A24A] text-xs font-bold animate-pulse">
              ⏳ جاري معالجة ورفع الصور لـ Supabase وتأكيد الإعلان... الرجاء الانتظار
            </div>
          )}

          <div className="flex justify-between pt-2">
            <button
              type="button"
              disabled={loading}
              onClick={() => setStep(3)}
              className="px-4 py-2.5 bg-zinc-800 text-gray-300 hover:text-white rounded-xl text-xs flex items-center gap-1 cursor-pointer disabled:opacity-50"
            >
              <ArrowRight className="h-4 w-4" />
              <span>السابق</span>
            </button>
            <button
              type="button"
              disabled={loading}
              onClick={handlePublishListing}
              className="px-8 py-3 bg-gradient-to-r from-gold to-amber-500 text-black font-extrabold text-xs rounded-xl flex items-center gap-1.5 shadow-xl hover:scale-105 transition-all cursor-pointer disabled:opacity-50"
            >
              <CheckCircle className="h-4 w-4" />
              <span>{loading ? 'جاري الحفظ والنشر...' : 'تأكيد ونشر الإعلان فوراً 🚀'}</span>
            </button>
          </div>
        </div>
      )}

    </div>
  );
}
