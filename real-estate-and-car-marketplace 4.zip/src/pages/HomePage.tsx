import { useState } from 'react';
import { useApp } from '../context/AppContext';
import { Sparkles, Filter } from 'lucide-react';
import { Link } from 'react-router-dom';

export default function HomePage() {
  const { properties, cars, currencyMode, users } = useApp();
  const [searchQuery, setSearchQuery] = useState('');
  const [filterCity, setFilterCity] = useState('');
  
  const formatSyp = (amount: number) => {
    if (amount >= 1000000000) {
      return `${(amount / 1000000000).toLocaleString(undefined, { maximumFractionDigits: 2 })} مليار ل.س`;
    }
    return `${amount.toLocaleString()} ل.س`;
  };

  const formatUsd = (amount: number) => `$${amount.toLocaleString()}`;

  const displayPrice = (syp: number, usd: number) => {
    if (currencyMode === 'syp') return formatSyp(syp);
    if (currencyMode === 'usd') return formatUsd(usd);
    return `${formatSyp(syp)} (~ ${formatUsd(usd)})`;
  };

  const SYRIAN_CITIES = ['دمشق', 'ريف دمشق', 'حلب', 'حمص', 'اللاذقية', 'طرطوس', 'حماة'];

  return (
    <div className="space-y-12 text-right">
      {/* Hero Header */}
      <div className="relative overflow-hidden gold-panel border border-[#C9A24A]/20 pb-12 pt-8 rounded-3xl p-6 gold-glow-strong">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-yellow-950/10 via-black to-black pointer-events-none"></div>
        <div className="relative text-center max-w-4xl mx-auto space-y-6">
          <div className="flex justify-center">
            <img
              src="/logo-golden-syria.svg"
              alt="Golden Syria Estates"
              className="h-28 w-auto sm:h-36 md:h-40 object-contain drop-shadow-[0_0_24px_rgba(201,162,74,0.28)]"
            />
          </div>

          <div className="inline-flex items-center gap-2 bg-[#C9A24A]/10 border border-[#C9A24A]/30 px-4 py-1.5 rounded-full text-[#C9A24A] text-xs font-semibold mb-2">
            <Sparkles className="h-4 w-4" />
            <span>واجهة فاخرة لعروض العقارات والسيارات في سورية</span>
          </div>

          <h1 className="text-3xl sm:text-5xl font-extrabold tracking-tight text-white leading-tight">
            العقارات السورية الذهبية <br />
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-[#FFF3C4] via-[#E9C86B] to-[#C9A24A] text-xl sm:text-3xl">
              بوابتك الموثوقة للعقارات والسيارات الفخمة بسورية بالدولار والليرة
            </span>
          </h1>

          <p className="text-gray-300 text-xs sm:text-sm leading-relaxed font-light max-w-2xl mx-auto">
            تصفح أحدث الإعلانات الموثقة، اعرض عقارك أو سيارتك بأسلوب فاخر، وتواصل مباشرة مع الوسطاء والوكلاء المعتمدين ضمن هوية سوداء ذهبية راقية.
          </p>
        </div>
      </div>

      {/* Quick Search */}
      <div className="bg-zinc-900/90 border-2 border-[#C9A24A] p-5 rounded-2xl shadow-2xl text-right max-w-4xl mx-auto">
        <h3 className="text-[#C9A24A] font-bold text-sm mb-3 flex items-center gap-1.5">
          <Filter className="h-4 w-4" />
          <span>البحث السريع المباشر:</span>
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <input
            type="text"
            placeholder="ابحث عن عقار، سيارة أو حي..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full bg-black border border-zinc-700 rounded-xl py-2.5 px-3 text-xs focus:outline-none focus:border-[#C9A24A] text-white"
          />
          <select
            value={filterCity}
            onChange={(e) => setFilterCity(e.target.value)}
            className="w-full bg-black border border-zinc-700 rounded-xl py-2.5 px-3 text-xs focus:outline-none focus:border-[#C9A24A] text-white"
          >
            <option value="">كل المحافظات</option>
            {SYRIAN_CITIES.map(city => <option key={city} value={city}>{city}</option>)}
          </select>
        </div>
      </div>

      {/* Properties Preview */}
      <div className="space-y-6">
        <div className="flex justify-between items-center">
          <h2 className="text-xl font-bold text-white">🏢 أحدث العقارات الموثقة</h2>
          <Link to="/properties" className="text-xs text-[#C9A24A] hover:underline">مشاهدة كل العقارات ←</Link>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {properties.slice(0, 3).map(item => (
            <Link to={`/properties/${item.id}`} key={item.id} className="bg-[#141414] rounded-2xl overflow-hidden border border-zinc-800 hover:border-[#C9A24A]/60 shadow-lg transform hover:-translate-y-1 transition-all block">
              <img src={item.image} className="w-full h-48 object-cover" />
              <div className="p-4 space-y-3">
                <span className="text-[10px] bg-[#C9A24A] text-black px-2 py-0.5 rounded font-black">{item.type}</span>
                <span className="mr-2 text-[10px] bg-zinc-800 text-gray-300 px-2 py-0.5 rounded">{item.city}</span>
                <h3 className="font-bold text-sm text-white line-clamp-1">{item.title}</h3>
                <p className="text-xs text-[#C9A24A] font-bold">{displayPrice(item.price, item.price_usd)}</p>
              </div>
            </Link>
          ))}
        </div>
      </div>

      {/* Cars Preview */}
      <div className="space-y-6">
        <div className="flex justify-between items-center">
          <h2 className="text-xl font-bold text-white">🚗 أحدث السيارات بالمعرض</h2>
          <Link to="/cars" className="text-xs text-[#C9A24A] hover:underline">مشاهدة كل السيارات ←</Link>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {cars.slice(0, 3).map(item => (
            <Link to={`/cars/${item.id}`} key={item.id} className="bg-[#141414] rounded-2xl overflow-hidden border border-zinc-800 hover:border-[#C9A24A]/60 shadow-lg transform hover:-translate-y-1 transition-all block">
              <img src={item.image} className="w-full h-48 object-cover" />
              <div className="p-4 space-y-3">
                <span className="text-[10px] bg-zinc-900 border border-[#C9A24A] text-[#C9A24A] px-2 py-0.5 rounded font-bold">الموديل {item.year}</span>
                <span className="mr-2 text-[10px] bg-zinc-800 text-gray-300 px-2 py-0.5 rounded">{item.city}</span>
                <h3 className="font-bold text-sm text-white line-clamp-1">{item.title}</h3>
                <p className="text-xs text-[#C9A24A] font-bold">{displayPrice(item.price, item.price_usd)}</p>
              </div>
            </Link>
          ))}
        </div>
      </div>

      {/* Showcase Certified Agents */}
      <div className="space-y-6 pt-6">
        <div className="border-r-4 border-[#C9A24A] pr-3">
          <h3 className="text-xl font-black text-white flex items-center gap-2">
            <span>👑</span> الوكلاء والمكاتب العقارية المعتمدة بالمنصة
          </h3>
          <p className="text-gray-400 text-xs">تواصل مباشرة مع أفضل الوسطاء المعتمدين في سورية</p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {users.filter(u => u.is_agent).map((agent) => (
            <div key={agent.id} className="p-5 bg-gradient-to-br from-[#121212] to-zinc-950 rounded-2xl border border-zinc-800 hover:border-[#C9A24A]/60 transition-all flex items-start gap-4">
              <div className="h-12 w-12 rounded-xl gold-gradient flex items-center justify-center text-black font-black text-lg shrink-0">🏢</div>
              <div className="space-y-1 text-right">
                <span className="font-bold text-white text-xs block">{agent.name}</span>
                <p className="text-[11px] text-gray-400">شركة: {agent.agent_company || 'مجموعة العقارات السورية الذهبية'}</p>
                <a href={`tel:${agent.agent_phone || '0944123456'}`} className="text-[10px] text-[#C9A24A] hover:underline font-bold block" dir="ltr">{agent.agent_phone || '0944123456'} 📞</a>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
