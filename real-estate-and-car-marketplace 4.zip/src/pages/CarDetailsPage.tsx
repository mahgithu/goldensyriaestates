import React, { useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { useApp } from '../context/AppContext';
import { Phone, ArrowRight, MapPin } from 'lucide-react';
import { supabase } from '../lib/supabase';

export default function CarDetailsPage() {
  const { id } = useParams<{ id: string }>();
  const { cars, isCloud, currentUser, showToastMessage } = useApp();
  const [directText, setDirectText] = useState('');

  const item = cars.find(c => c.id === id);

  if (!item) {
    return (
      <div className="text-center py-16 space-y-4">
        <h2 className="text-xl font-bold text-white">السيارة المطلوبة غير موجودة بالمعرض ⚠️</h2>
        <Link to="/cars" className="text-xs text-gold hover:underline">العودة لمعرض السيارات</Link>
      </div>
    );
  }

  const handleMessageSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!directText.trim()) return;

    const newMsg = {
      id: 'msg-' + Date.now(),
      name: currentUser ? currentUser.name : 'عميل مهتم',
      email: currentUser ? currentUser.email : 'visitor@golden.sy',
      message: directText,
      listing_title: item.title,
      created_at: new Date().toISOString()
    };

    if (isCloud) {
      await supabase.from('messages').insert([newMsg]);
    }

    setDirectText('');
    showToastMessage('تم إرسال رسالتك بخصوص السيارة للإدارة بنجاح!', 'success');
  };

  return (
    <div className="max-w-3xl mx-auto space-y-6 text-right">
      <Link to="/cars" className="inline-flex items-center gap-1 text-xs text-gray-400 hover:text-white mb-2">
        <ArrowRight className="h-3 w-3" />
        <span>العودة لمعرض السيارات</span>
      </Link>

      <div className="bg-[#121212] border border-zinc-800 rounded-2xl overflow-hidden shadow-2xl">
        <img src={item.image} alt={item.title} className="w-full h-80 object-cover" />
        
        <div className="p-6 space-y-6">
          <div className="flex justify-between items-start gap-4 flex-wrap">
            <div>
              <span className="bg-zinc-900 border border-[#C9A24A] text-[#C9A24A] text-[10px] font-bold px-2.5 py-1 rounded">الموديل {item.year}</span>
              <span className="mr-2 text-[10px] bg-zinc-800 text-gray-300 px-2.5 py-1 rounded inline-flex items-center gap-1">
                <MapPin className="h-3 w-3 text-[#C9A24A]" />
                {item.city}
              </span>
              <h1 className="text-xl sm:text-2xl font-black text-white mt-3">{item.title}</h1>
              <p className="text-xs text-[#C9A24A] font-semibold">{item.name} | {item.model}</p>
            </div>
            <div className="text-left bg-zinc-900 p-3 rounded-xl border border-zinc-800">
              <p className="text-[10px] text-gray-400">السعر الإجمالي المطلوب:</p>
              <p className="text-md font-black text-[#C9A24A]">{item.price.toLocaleString()} ل.س</p>
              <p className="text-xs text-emerald-400">${item.price_usd.toLocaleString()}</p>
            </div>
          </div>

          <div className="space-y-2">
            <h4 className="font-bold text-sm text-[#C9A24A]">المواصفات والحالة الفنية للسيارة:</h4>
            <p className="text-xs text-gray-300 leading-relaxed bg-black/40 p-4 rounded-xl border border-zinc-800">
              {item.description}
            </p>
          </div>

          <div className="p-4 bg-black/50 rounded-xl border border-[#C9A24A]/20 flex flex-wrap items-center justify-between gap-4">
            <div>
              <p className="text-[10px] text-gray-400">رقم تواصل صاحب السيارة للبيع:</p>
              <p className="font-bold text-white text-sm" dir="ltr">{item.user_phone}</p>
            </div>
            <div className="flex gap-2">
              <a href={`tel:${item.user_phone}`} className="bg-green-600 hover:bg-green-700 text-white font-bold p-2 px-3 rounded-lg text-xs flex items-center gap-1">
                <Phone className="h-3 w-3" />
                <span>اتصال مباشر</span>
              </a>
              <a href={`https://wa.me/${item.user_phone.replace(/^0/, '+963')}`} target="_blank" rel="noopener noreferrer" className="bg-emerald-600 hover:bg-emerald-700 text-white font-bold p-2 px-3 rounded-lg text-xs">واتساب</a>
            </div>
          </div>

          <form onSubmit={handleMessageSubmit} className="space-y-3 pt-4 border-t border-zinc-800">
            <h4 className="text-xs font-bold text-white">هل تود الاستفسار وطلب تجريب ومعاينة السيارة؟</h4>
            <div className="flex gap-2">
              <input 
                type="text" 
                placeholder="اكتب استفسارك السريع هنا بخصوص السيارة..." 
                value={directText} 
                onChange={(e) => setDirectText(e.target.value)} 
                className="flex-1 bg-black border border-zinc-800 rounded-xl p-2.5 text-xs text-white focus:outline-none focus:border-[#C9A24A]"
              />
              <button type="submit" className="bg-[#C9A24A] hover:bg-[#E5BA5A] text-black font-extrabold px-4 rounded-xl text-xs">إرسال استفسارك</button>
            </div>
          </form>

        </div>
      </div>
    </div>
  );
}
