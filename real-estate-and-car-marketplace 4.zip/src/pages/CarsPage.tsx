import { useState } from 'react';
import { useApp } from '../context/AppContext';
import { Heart } from 'lucide-react';
import { Link } from 'react-router-dom';

export default function CarsPage() {
  const { cars, currencyMode, favorites, toggleFavorite } = useApp();
  const [searchQuery, setSearchQuery] = useState('');
  const [filterCity, setFilterCity] = useState('');

  const formatSyp = (amount: number) => {
    if (amount >= 1000000000) {
      return `${(amount / 1000000000).toLocaleString(undefined, { maximumFractionDigits: 2 })} مليار ل.س`;
    }
    return `${amount.toLocaleString()} ل.س`;
  };

  const formatUsd = (amount: number) => `$${amount.toLocaleString()}`;

  const displayPrice = (syp: number, usd: number) => {
    if (currencyMode === 'syp') return formatSyp(syp);
    if (currencyMode === 'usd') return formatUsd(usd);
    return `${formatSyp(syp)} (~ ${formatUsd(usd)})`;
  };

  const SYRIAN_CITIES = ['دمشق', 'ريف دمشق', 'حلب', 'حمص', 'اللاذقية', 'طرطوس', 'حماة'];

  const filtered = cars.filter(c => {
    const matchesSearch = c.title.toLowerCase().includes(searchQuery.toLowerCase()) || c.description.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCity = filterCity === '' || c.city === filterCity;
    return matchesSearch && matchesCity;
  });

  return (
    <div className="space-y-8 text-right">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl md:text-3xl font-black text-white">🚗 صالة عرض السيارات الفاخرة</h1>
          <p className="text-gray-400 text-xs mt-1">تصفح وقارن أحدث الموديلات المتاحة للتسجيل الفوري بالدولار والليرة</p>
        </div>
      </div>

      {/* Filter Bar */}
      <div className="bg-zinc-900/80 p-5 rounded-2xl border border-zinc-800 grid grid-cols-1 md:grid-cols-2 gap-4">
        <input 
          type="text" 
          placeholder="ابحث بالاسم أو الماركة..." 
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="bg-black border border-zinc-700 rounded-xl p-2.5 text-xs text-white focus:border-[#C9A24A] focus:outline-none"
        />
        <select 
          value={filterCity}
          onChange={(e) => setFilterCity(e.target.value)}
          className="bg-black border border-zinc-700 rounded-xl p-2.5 text-xs text-white focus:border-[#C9A24A] focus:outline-none"
        >
          <option value="">كل المدن</option>
          {SYRIAN_CITIES.map(c => <option key={c} value={c}>{c}</option>)}
        </select>
      </div>

      {/* Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filtered.map(item => (
          <div key={item.id} className="bg-[#141414] rounded-2xl overflow-hidden border border-zinc-800 hover:border-[#C9A24A]/60 shadow-lg cursor-pointer transform hover:-translate-y-1 transition-all">
            <div className="relative h-48 bg-zinc-800">
              <img src={item.image} alt={item.title} className="w-full h-full object-cover" />
              <button 
                onClick={(e) => toggleFavorite(item.id, e)}
                className="absolute top-3 left-3 h-8 w-8 rounded-full bg-black/60 flex items-center justify-center text-white hover:text-red-500"
              >
                <Heart className={`h-4 w-4 ${favorites.includes(item.id) ? 'fill-red-600 text-red-600' : ''}`} />
              </button>
              <span className="absolute bottom-3 right-3 bg-zinc-900 border border-[#C9A24A] text-[#C9A24A] text-[10px] font-bold px-2.5 py-0.5 rounded">
                الموديل {item.year}
              </span>
            </div>
            <div className="p-4 space-y-3">
              <h3 className="font-bold text-sm text-white line-clamp-1">{item.title}</h3>
              <p className="text-xs text-[#C9A24A] font-semibold">{item.name} | {item.model}</p>
              <p className="text-xs text-gray-400 line-clamp-2">{item.description}</p>
              <div className="flex justify-between items-center pt-2 border-t border-zinc-800">
                <span className="text-xs font-black text-[#C9A24A]">{displayPrice(item.price, item.price_usd)}</span>
                <Link to={`/cars/${item.id}`} className="text-xs text-gold hover:underline">عرض التفاصيل ←</Link>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
