import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { supabase } from '../lib/supabase';

export default function MessagesPage() {
  const { messages, setMessages, isCloud, showToastMessage } = useApp();
  const [contactName, setContactName] = useState('');
  const [contactEmail, setContactEmail] = useState('');
  const [contactMessage, setContactMessage] = useState('');

  const handleContactSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!contactName || !contactEmail || !contactMessage) {
      showToastMessage('يرجى كتابة الاسم والبريد ونص الرسالة بالكامل.', 'error');
      return;
    }

    const newMsg = {
      id: 'msg-' + Date.now(),
      name: contactName,
      email: contactEmail,
      message: contactMessage,
      created_at: new Date().toISOString()
    };

    setMessages([newMsg, ...messages]);
    setContactName('');
    setContactEmail('');
    setContactMessage('');

    if (isCloud) {
      await supabase.from('messages').insert([newMsg]);
    }

    showToastMessage('تم إرسال رسالتك بنجاح للإدارة! سنقوم بمراجعتها والرد فوراً.', 'success');
  };

  return (
    <div className="max-w-4xl mx-auto space-y-12 text-right">
      <div className="text-center space-y-3">
        <h1 className="text-3xl font-black text-white">تواصل مع إدارة المنصة الفاخرة 💬</h1>
        <p className="text-gray-400 text-xs">يسعدنا الرد على جميع استفساراتكم بخصوص توثيق العقود والتحويلات المالية في سورية</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        <div className="md:col-span-1 p-5 bg-zinc-900 rounded-2xl border border-zinc-800 space-y-4 h-fit text-xs">
          <h3 className="font-bold text-[#C9A24A] border-b border-zinc-800 pb-2 text-sm">تفاصيل الاتصال الرسمية</h3>
          <p className="text-gray-300"><strong>المكتب الرئيسي:</strong> دمشق، اتוستراد المزة، برج الفصول الذهبية، الطابق الثالث</p>
          <p className="text-gray-300" dir="ltr"><strong>هاتف الدعم الموحد:</strong> +963 944 123 456</p>
          <p className="text-gray-300"><strong>البريد الإلكتروني:</strong> support@golden.sy</p>
        </div>

        <div className="md:col-span-2">
          <form onSubmit={handleContactSubmit} className="bg-zinc-900 p-6 rounded-2xl border border-zinc-800 space-y-4">
            <div>
              <label className="block text-xs text-gray-400 mb-1">الاسم الكامل *</label>
              <input 
                type="text" 
                required
                placeholder="أدخل اسمك الكريم"
                value={contactName}
                onChange={(e) => setContactName(e.target.value)}
                className="w-full bg-black border border-zinc-700 rounded-xl p-3 text-xs text-white"
              />
            </div>

            <div>
              <label className="block text-xs text-gray-400 mb-1">البريد الإلكتروني أو رقم الجوال *</label>
              <input 
                type="text" 
                required
                placeholder="مثال: 0944000000"
                value={contactEmail}
                onChange={(e) => setContactEmail(e.target.value)}
                className="w-full bg-black border border-zinc-700 rounded-xl p-3 text-xs text-white"
              />
            </div>

            <div>
              <label className="block text-xs text-gray-400 mb-1">نص الاستفسار أو تفاصيل العرض *</label>
              <textarea 
                rows={4}
                required
                placeholder="اكتب رسالتك بالتفصيل هنا..."
                value={contactMessage}
                onChange={(e) => setContactMessage(e.target.value)}
                className="w-full bg-black border border-zinc-700 rounded-xl p-3 text-xs text-white focus:outline-none"
              ></textarea>
            </div>

            <button type="submit" className="w-full py-3 bg-[#C9A24A] text-black font-extrabold rounded-xl text-xs">
              إرسال الرسالة للإدارة العامة ✉
            </button>
          </form>
        </div>
      </div>
    </div>
  );
}
