import AgentManagementPanel from '../components/AgentManagementPanel';
import { useApp } from '../context/AppContext';

export default function AdminDashboardPage() {
  const { currentUser } = useApp();

  if (currentUser?.role !== 'admin') {
    return (
      <div className="text-center py-16 text-right">
        <p className="text-gray-400 text-sm">هذه الصفحة مخصصة للمدير المطلق فقط.</p>
      </div>
    );
  }

  return (
    <div className="space-y-8 text-right max-w-6xl mx-auto">
      <div className="bg-gradient-to-r from-amber-950/20 via-black to-zinc-950 p-6 rounded-3xl border-2 border-[#C9A24A]">
        <h1 className="text-2xl font-black text-[#C9A24A]">👑 لوحة تحكم المدير المطلق</h1>
        <p className="text-gray-400 text-xs mt-2">من هنا يمكنك إدارة الوكلاء بالكامل: إضافة، تعديل، حذف، ومراجعة الجدول المنظم.</p>
      </div>
      <AgentManagementPanel />
    </div>
  );
}
