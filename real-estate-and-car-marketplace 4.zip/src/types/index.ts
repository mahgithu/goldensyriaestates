export interface UserProfile {
  id: string;
  name: string;
  email: string;
  role: 'admin' | 'user';
  banned?: boolean;
  is_agent?: boolean;
  agent_company?: string;
  agent_phone?: string;
  created_at?: string;
}

export interface Property {
  id: string;
  title: string;
  price: number;
  price_usd: number;
  city: string;
  description: string;
  image: string;
  type: 'شقة' | 'فيلا' | 'أرض' | 'محل';
  user_id: string;
  user_phone: string;
  area: number;
  rooms?: number;
  created_at?: string;
}

export interface Car {
  id: string;
  title: string;
  name: string;
  model: string;
  price: number;
  price_usd: number;
  city: string;
  description: string;
  image: string;
  user_id: string;
  user_phone: string;
  year: string;
  created_at?: string;
}

export interface Message {
  id: string;
  name: string;
  email: string;
  message: string;
  listing_title?: string;
  created_at?: string;
}
