import { createClient } from '@supabase/supabase-js';

const metaEnv = (import.meta as any).env || {};

const supabaseUrl = metaEnv.VITE_SUPABASE_URL || 'https://placeholder-project.supabase.co';
const supabaseAnonKey = metaEnv.VITE_SUPABASE_ANON_KEY || 'placeholder-key-abc123xyz';

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

/**
 * Checks if Supabase has real configured credentials (not placeholders).
 */
export const isSupabaseConfigured = (): boolean => {
  return (
    metaEnv.VITE_SUPABASE_URL && 
    metaEnv.VITE_SUPABASE_ANON_KEY &&
    !metaEnv.VITE_SUPABASE_URL.includes('placeholder')
  );
};

/**
 * Uploads a local file or Base64 string to the 'images' storage bucket on Supabase.
 * Returns the public URL of the uploaded image.
 */
export const uploadImageToSupabase = async (
  fileOrBase64: File | string, 
  bucketName: string = 'images'
): Promise<string> => {
  if (!isSupabaseConfigured()) {
    // If Supabase is not configured, we return the base64 or a mock url directly
    return typeof fileOrBase64 === 'string' ? fileOrBase64 : URL.createObjectURL(fileOrBase64);
  }

  try {
    let fileToUpload: File | Blob;
    let fileName = `img_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;

    if (typeof fileOrBase64 === 'string') {
      // It's a Base64 string from phone/laptop upload
      const response = await fetch(fileOrBase64);
      fileToUpload = await response.blob();
      fileName += '.png';
    } else {
      fileToUpload = fileOrBase64;
      fileName += `_${fileOrBase64.name}`;
    }

    const { error: uploadError } = await supabase.storage
      .from(bucketName)
      .upload(fileName, fileToUpload, {
        cacheControl: '3600',
        upsert: false,
      });

    if (uploadError) {
      throw uploadError;
    }

    const { data } = supabase.storage
      .from(bucketName)
      .getPublicUrl(fileName);

    return data.publicUrl;
  } catch (error) {
    console.error('Error in uploadImageToSupabase:', error);
    // Safe fallback to the object representation so nothing crashes
    return typeof fileOrBase64 === 'string' ? fileOrBase64 : URL.createObjectURL(fileOrBase64);
  }
};
