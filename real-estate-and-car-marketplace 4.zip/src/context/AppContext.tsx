import React, { createContext, useContext, useState, useEffect } from 'react';
import { supabase, isSupabaseConfigured } from '../lib/supabase';
import { UserProfile, Property, Car, Message } from '../types';

interface AppContextType {
  users: UserProfile[];
  properties: Property[];
  cars: Car[];
  messages: Message[];
  favorites: string[];
  currentUser: UserProfile | null;
  currencyMode: 'both' | 'syp' | 'usd';
  isLoading: boolean;
  dbStatus: string;
  isCloud: boolean;
  setCurrencyMode: (mode: 'both' | 'syp' | 'usd') => void;
  setCurrentUser: (user: UserProfile | null) => void;
  setFavorites: (favs: string[]) => void;
  toggleFavorite: (id: string, e: React.MouseEvent) => void;
  setProperties: React.Dispatch<React.SetStateAction<Property[]>>;
  setCars: React.Dispatch<React.SetStateAction<Car[]>>;
  setUsers: React.Dispatch<React.SetStateAction<UserProfile[]>>;
  setMessages: React.Dispatch<React.SetStateAction<Message[]>>;
  loadDatabase: () => Promise<void>;
  addAgent: (payload: { name: string; phone: string; company?: string; email?: string }) => Promise<void>;
  updateAgent: (agentId: string, payload: { name: string; phone: string; company?: string }) => Promise<void>;
  deleteAgent: (agentId: string) => Promise<void>;
  showToastMessage: (msg: string, type?: 'success' | 'error' | 'info') => void;
  toast: { message: string; type: 'success' | 'error' | 'info' } | null;
  setToast: (toast: { message: string; type: 'success' | 'error' | 'info' } | null) => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [users, setUsers] = useState<UserProfile[]>([]);
  const [properties, setProperties] = useState<Property[]>([]);
  const [cars, setCars] = useState<Car[]>([]);
  const [messages, setMessages] = useState<Message[]>([]);
  const [favorites, setFavorites] = useState<string[]>([]);
  const [currentUser, setCurrentUser] = useState<UserProfile | null>(null);
  const [currencyMode, setCurrencyMode] = useState<'both' | 'syp' | 'usd'>('both');
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [dbStatus, setDbStatus] = useState<string>('توصيل...');
  const [isCloud, setIsCloud] = useState<boolean>(false);
  const [toast, setToast] = useState<{ message: string; type: 'success' | 'error' | 'info' } | null>(null);

  const showToastMessage = (message: string, type: 'success' | 'error' | 'info' = 'success') => {
    setToast({ message, type });
    setTimeout(() => setToast(null), 4000);
  };

  const loadDatabase = async () => {
    setIsLoading(true);
    const configured = isSupabaseConfigured();
    if (!configured) {
      setDbStatus('الوضع التجريبي السريع 📡');
      setIsCloud(false);
      setIsLoading(false);
      return;
    }

    try {
      setDbStatus('متصل بقاعدة البيانات السحابية ⚡');
      setIsCloud(true);

      const { data: dbProps } = await supabase.from('properties').select('*');
      if (dbProps) setProperties(dbProps);

      const { data: dbCars } = await supabase.from('cars').select('*');
      if (dbCars) setCars(dbCars);

      const { data: dbUsers } = await supabase.from('profiles').select('*');
      if (dbUsers) setUsers(dbUsers);

      const { data: dbMsgs } = await supabase.from('messages').select('*');
      if (dbMsgs) setMessages(dbMsgs);

      const { data: { session } } = await supabase.auth.getSession();
      if (session && session.user) {
        const { data: profile } = await supabase
          .from('profiles')
          .select('*')
          .eq('id', session.user.id)
          .single();

        if (profile) {
          const normalizedProfile: UserProfile = {
            ...(profile as UserProfile),
            role: session.user.email?.toLowerCase() === 'admin@golden.sy' ? 'admin' : (profile as UserProfile).role,
          };

          if (session.user.email?.toLowerCase() === 'admin@golden.sy' && (profile as UserProfile).role !== 'admin') {
            await supabase.from('profiles').update({ role: 'admin' }).eq('id', session.user.id);
          }

          setCurrentUser(normalizedProfile);
        }
      }
    } catch (err) {
      console.error(err);
      setDbStatus('الوضع الاحتياطي الفعال 📡');
    } finally {
      setIsLoading(false);
    }
  };

  const toggleFavorite = async (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    let updated: string[];
    if (favorites.includes(id)) {
      updated = favorites.filter(favId => favId !== id);
      showToastMessage('تم إزالة الإعلان من المفضلة', 'info');
      if (isCloud && currentUser) {
        await supabase.from('favorites').delete().eq('user_id', currentUser.id).eq('listing_id', id);
      }
    } else {
      updated = [...favorites, id];
      showToastMessage('تم إضافة الإعلان إلى المفضلة ❤️', 'success');
      if (isCloud && currentUser) {
        await supabase.from('favorites').insert([{ user_id: currentUser.id, listing_id: id }]);
      }
    }
    setFavorites(updated);
  };

  const addAgent = async (payload: { name: string; phone: string; company?: string; email?: string }) => {
    if (currentUser?.role !== 'admin') {
      throw new Error('غير مصرح لك بإضافة وكلاء. هذه العملية للمدير فقط.');
    }

    const newAgent: UserProfile = {
      id: `agent-${Date.now()}`,
      name: payload.name,
      email: payload.email || `agent-${Date.now()}@golden.sy`,
      role: 'user',
      is_agent: true,
      agent_phone: payload.phone,
      agent_company: payload.company || 'وكالة العقارات السورية الذهبية',
      banned: false,
    };

    setUsers((prev) => [newAgent, ...prev]);

    if (isCloud) {
      const { error } = await supabase.from('profiles').upsert([newAgent]);
      if (error) {
        setUsers((prev) => prev.filter((u) => u.id !== newAgent.id));
        throw error;
      }
    }

    showToastMessage(`تمت إضافة الوكيل ${payload.name} بنجاح`, 'success');
  };

  const updateAgent = async (agentId: string, payload: { name: string; phone: string; company?: string }) => {
    if (currentUser?.role !== 'admin') {
      throw new Error('غير مصرح لك بتعديل الوكلاء. هذه العملية للمدير فقط.');
    }

    setUsers((prev) => prev.map((u) => u.id === agentId ? {
      ...u,
      name: payload.name,
      agent_phone: payload.phone,
      agent_company: payload.company || u.agent_company
    } : u));

    if (currentUser?.id === agentId) {
      setCurrentUser((prev) => prev ? {
        ...prev,
        name: payload.name,
        agent_phone: payload.phone,
        agent_company: payload.company || prev.agent_company
      } : prev);
    }

    if (isCloud) {
      const { error } = await supabase.from('profiles').update({
        name: payload.name,
        agent_phone: payload.phone,
        agent_company: payload.company || null,
      }).eq('id', agentId);
      if (error) throw error;
    }

    showToastMessage('تم تعديل بيانات الوكيل بنجاح', 'success');
  };

  const deleteAgent = async (agentId: string) => {
    if (currentUser?.role !== 'admin') {
      throw new Error('غير مصرح لك بحذف الوكلاء. هذه العملية للمدير فقط.');
    }

    const target = users.find((u) => u.id === agentId);
    setUsers((prev) => prev.filter((u) => u.id !== agentId));

    if (isCloud) {
      const { error } = await supabase.from('profiles').delete().eq('id', agentId);
      if (error) throw error;
    }

    showToastMessage(`تم حذف الوكيل ${target?.name || ''} بنجاح`, 'info');
  };

  useEffect(() => {
    loadDatabase();
  }, []);

  return (
    <AppContext.Provider value={{
      users, properties, cars, messages, favorites, currentUser, currencyMode, isLoading, dbStatus, isCloud,
      setCurrencyMode, setCurrentUser, setFavorites, toggleFavorite, setProperties, setCars, setUsers, setMessages, loadDatabase,
      addAgent, updateAgent, deleteAgent, showToastMessage, toast, setToast
    }}>
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) throw new Error('useApp must be used within AppProvider');
  return context;
};
