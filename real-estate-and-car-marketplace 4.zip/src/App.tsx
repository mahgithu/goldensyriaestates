import React, { Suspense } from 'react';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import { HelmetProvider, Helmet } from 'react-helmet-async';
import { AppProvider } from './context/AppContext';
import MainLayout from './layouts/MainLayout';
import ErrorBoundary from './components/ErrorBoundary';
import { ProtectedRoute, AdminRoute } from './components/ProtectedRoute';

// Professional Lazy Loaded Page Components
const HomePage = React.lazy(() => import('./pages/HomePage'));
const PropertiesPage = React.lazy(() => import('./pages/PropertiesPage'));
const CarsPage = React.lazy(() => import('./pages/CarsPage'));
const PropertyDetailsPage = React.lazy(() => import('./pages/PropertyDetailsPage'));
const CarDetailsPage = React.lazy(() => import('./pages/CarDetailsPage'));
const MessagesPage = React.lazy(() => import('./pages/MessagesPage'));
const ProfilePage = React.lazy(() => import('./pages/ProfilePage'));
const LoginPage = React.lazy(() => import('./pages/LoginPage'));
const RegisterPage = React.lazy(() => import('./pages/RegisterPage'));
const AddListingPage = React.lazy(() => import('./pages/AddListingPage'));
const AdminDashboardPage = React.lazy(() => import('./pages/AdminDashboardPage'));

// Elegant Loading Skeleton Component
function LoadingSkeleton() {
  return (
    <div className="space-y-6 py-12 text-center text-right max-w-4xl mx-auto" dir="rtl">
      <div className="h-8 bg-zinc-800 rounded w-1/3 mx-auto animate-pulse"></div>
      <div className="h-4 bg-zinc-800 rounded w-2/3 mx-auto animate-pulse"></div>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 pt-8">
        <div className="h-48 bg-zinc-900 rounded-2xl animate-pulse border border-zinc-800"></div>
        <div className="h-48 bg-zinc-900 rounded-2xl animate-pulse border border-zinc-800"></div>
        <div className="h-48 bg-zinc-900 rounded-2xl animate-pulse border border-zinc-800"></div>
      </div>
    </div>
  );
}

export default function App() {
  return (
    <ErrorBoundary>
      <HelmetProvider>
        <AppProvider>
          <BrowserRouter>
            <Helmet>
              <title>العقارات السورية الذهبية | الشقق، الفلل والسيارات الفاخرة</title>
              <meta name="description" content="البوابة الأولى والأرقى لعرض وبيع العقارات والسيارات النخبوية بالجمهورية العربية السورية بالدولار والليرة" />
              <meta name="keywords" content="عقارات سورية, شقق دمشق, فيلا يعفور, سيارات مرسيدس دمشق, وسيط عقاري معتمد" />
            </Helmet>
            <Suspense fallback={<LoadingSkeleton />}>
              <Routes>
                <Route path="/" element={<MainLayout />}>
                  <Route index element={<HomePage />} />
                  <Route path="properties" element={<PropertiesPage />} />
                  <Route path="properties/:id" element={<PropertyDetailsPage />} />
                  <Route path="cars" element={<CarsPage />} />
                  <Route path="cars/:id" element={<CarDetailsPage />} />
                  <Route path="contact" element={<MessagesPage />} />
                  <Route path="login" element={<LoginPage />} />
                  <Route path="register" element={<RegisterPage />} />

                  <Route element={<ProtectedRoute />}>
                    <Route path="add-listing" element={<AddListingPage />} />
                    <Route path="profile" element={<ProfilePage />} />
                  </Route>

                  <Route element={<AdminRoute />}>
                    <Route path="admin" element={<AdminDashboardPage />} />
                  </Route>

                  <Route path="*" element={<HomePage />} />
                </Route>
              </Routes>
            </Suspense>
          </BrowserRouter>
        </AppProvider>
      </HelmetProvider>
    </ErrorBoundary>
  );
}
