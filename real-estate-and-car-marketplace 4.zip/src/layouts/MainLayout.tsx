import { Link, NavLink, Outlet } from 'react-router-dom';
import { useApp } from '../context/AppContext';
import { LogOut, Home as HomeIcon, Building, CarIcon, Heart, MessageSquare as MsgIcon } from 'lucide-react';

export default function MainLayout() {
  const { currentUser, currencyMode, setCurrencyMode, favorites } = useApp();

  const handleLogout = () => {
    window.location.reload();
  };

  return (
    <div className="min-h-screen bg-[#0F0F0F] text-white selection:bg-[#C9A24A] selection:text-black pb-12 text-right">
      
      {/* LUXURY GOLDEN STICKY HEADER */}
      <header className="sticky top-0 z-40 bg-[#0B0B0B]/95 border-b border-[#C9A24A]/30 backdrop-blur-md gold-glow-strong">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-24 gap-4">
            
            {/* Logo Brand */}
            <Link to="/" className="flex items-center space-x-3 space-x-reverse cursor-pointer min-w-0">
              <img
                src="/logo-golden-syria.svg"
                alt="Golden Syria Estates Logo"
                className="h-14 w-auto sm:h-16 md:h-18 object-contain drop-shadow-[0_0_18px_rgba(201,162,74,0.25)]"
              />
              <div className="min-w-0 hidden sm:block">
                <span className="text-lg md:text-xl font-black tracking-wider text-transparent bg-clip-text bg-gradient-to-r from-white via-[#F3E5AB] to-[#C9A24A] block truncate">
                  العقارات السورية الذهبية
                </span>
                <p className="text-[9px] text-gray-400 tracking-[0.25em] text-right">GOLDEN SYRIA ESTATES</p>
              </div>
            </Link>

            {/* Desktop Navigation Links */}
            <nav className="hidden lg:flex items-center space-x-1 space-x-reverse text-xs font-bold">
              <NavLink to="/" className={({ isActive }) => `px-3.5 py-2 rounded-lg transition-all ${isActive ? 'bg-[#C9A24A] text-black' : 'text-gray-300 hover:text-white'}`}>🏠 الرئيسية</NavLink>
              <NavLink to="/properties" className={({ isActive }) => `px-3.5 py-2 rounded-lg transition-all ${isActive ? 'bg-[#C9A24A] text-black' : 'text-gray-300 hover:text-white'}`}>🏢 قسم العقارات</NavLink>
              <NavLink to="/cars" className={({ isActive }) => `px-3.5 py-2 rounded-lg transition-all ${isActive ? 'bg-[#C9A24A] text-black' : 'text-gray-300 hover:text-white'}`}>🚗 قسم السيارات</NavLink>
              <NavLink to="/contact" className={({ isActive }) => `px-3.5 py-2 rounded-lg transition-all ${isActive ? 'bg-[#C9A24A] text-black' : 'text-gray-300 hover:text-white'}`}>💬 تواصل معنا</NavLink>
              <NavLink to="/favorites" className={({ isActive }) => `px-3.5 py-2 rounded-lg transition-all ${isActive ? 'bg-[#C9A24A] text-black' : 'text-gray-300 hover:text-white'}`}>❤️ المفضلة ({favorites.length})</NavLink>
              <NavLink to="/add-listing" className="px-3.5 py-2 rounded-lg transition-all bg-gold/10 text-gold border border-gold/30 hover:bg-gold hover:text-black">➕ أضف إعلانك</NavLink>
              {currentUser?.role === 'admin' && <NavLink to="/admin" className={({ isActive }) => `px-3.5 py-2 rounded-lg transition-all ${isActive ? 'bg-[#C9A24A] text-black' : 'bg-[#C9A24A]/10 text-[#C9A24A] border border-[#C9A24A]/30 hover:bg-[#C9A24A] hover:text-black'}`}>👑 لوحة الإدارة</NavLink>}
              {currentUser && <NavLink to="/profile" className={({ isActive }) => `px-3.5 py-2 rounded-lg transition-all ${isActive ? 'bg-[#C9A24A] text-black' : 'text-gray-300 hover:text-white'}`}>👤 حسابي</NavLink>}
            </nav>

            {/* Right Buttons: Currency Selector */}
            <div className="flex items-center space-x-2 space-x-reverse">
              <div className="bg-zinc-900 border border-zinc-800 rounded-xl p-1 flex items-center">
                <button 
                  onClick={() => setCurrencyMode('both')}
                  className={`px-2 py-1 text-[9px] rounded font-bold ${currencyMode === 'both' ? 'bg-[#C9A24A] text-black' : 'text-gray-400'}`}
                >
                  الكل
                </button>
                <button 
                  onClick={() => setCurrencyMode('syp')}
                  className={`px-2 py-1 text-[9px] rounded font-bold ${currencyMode === 'syp' ? 'bg-[#C9A24A] text-black' : 'text-gray-400'}`}
                >
                  ل.س
                </button>
                <button 
                  onClick={() => setCurrencyMode('usd')}
                  className={`px-2 py-1 text-[9px] rounded font-bold ${currencyMode === 'usd' ? 'bg-[#C9A24A] text-black' : 'text-gray-400'}`}
                >
                  $
                </button>
              </div>

              {currentUser ? (
                <div className="flex items-center space-x-1.5 space-x-reverse bg-zinc-900 border border-zinc-800 p-1.5 px-3 rounded-xl">
                  <span className="text-xs font-bold text-[#C9A24A]">{currentUser.name}</span>
                  <button 
                    onClick={handleLogout} 
                    className="p-1 bg-red-950/40 text-red-400 hover:bg-red-900 hover:text-white rounded"
                  >
                    <LogOut className="h-3 w-3" />
                  </button>
                </div>
              ) : (
                <Link
                  to="/login"
                  className="px-3 py-1.5 bg-zinc-900 hover:bg-zinc-800 border border-[#C9A24A]/40 text-xs text-[#C9A24A] hover:text-white rounded-xl transition-all font-semibold flex items-center gap-1 cursor-pointer"
                >
                  <span>دخول الأعضاء</span>
                </Link>
              )}
            </div>

          </div>
        </div>
      </header>

      {/* MOBILE BOTTOM NAVIGATION BAR */}
      <div className="lg:hidden fixed bottom-0 left-0 right-0 z-50 bg-[#0F0F0F] border-t border-[#C9A24A]/30 flex justify-around py-3 px-2 shadow-2xl">
        <Link to="/" className="flex flex-col items-center gap-1 text-gray-400">
          <HomeIcon className="h-5 w-5" />
          <span className="text-[10px]">الرئيسية</span>
        </Link>
        <Link to="/properties" className="flex flex-col items-center gap-1 text-gray-400">
          <Building className="h-5 w-5" />
          <span className="text-[10px]">العقارات</span>
        </Link>
        <Link to="/cars" className="flex flex-col items-center gap-1 text-gray-400">
          <CarIcon className="h-5 w-5" />
          <span className="text-[10px]">السيارات</span>
        </Link>
        <Link to="/favorites" className="flex flex-col items-center gap-1 text-gray-400">
          <Heart className="h-5 w-5" />
          <span className="text-[10px]">المفضلة</span>
        </Link>
        <Link to="/add-listing" className="flex flex-col items-center gap-1 text-gold font-bold">
          <span className="text-sm">➕</span>
          <span className="text-[10px]">أضف إعلانك</span>
        </Link>
        {currentUser?.role === 'admin' && (
          <Link to="/admin" className="flex flex-col items-center gap-1 text-gold font-bold">
            <span className="text-sm">👑</span>
            <span className="text-[10px]">الإدارة</span>
          </Link>
        )}
        <Link to="/contact" className="flex flex-col items-center gap-1 text-gray-400">
          <MsgIcon className="h-5 w-5" />
          <span className="text-[10px]">تواصل</span>
        </Link>
      </div>

      {/* MAIN CONTAINER */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 pb-32">
        <Outlet />
      </main>

      {/* FOOTER SECTION */}
      <footer className="bg-black text-gray-400 text-right text-xs pt-12 pb-24 border-t border-[#C9A24A]/20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-8">
            <div className="space-y-3">
              <span className="text-lg font-black text-white block">العقارات السورية الذهبية</span>
              <p className="text-gray-400 text-[11px] leading-relaxed">
                منصة الرفاهية الأولى لعرض العقارات والسيارات النخبوية بسورية. رفع ومزامنة وحفظ فوري للصور للجميع.
              </p>
            </div>
            <div>
              <span className="text-sm font-bold text-white block mb-2">📞 تواصل مباشر</span>
              <p className="text-[#C9A24A] text-xs">هاتف الدعم الموحد: 0944123456</p>
              <p className="text-gray-500 text-[10px] mt-1">المنصة الذهبية للتحويل والتوثيق العقاري والسيارات.</p>
            </div>
            <div>
              <span className="text-sm font-bold text-white block mb-2">⭐ خدمات المنصة الذهبية</span>
              <p className="text-gray-500 text-[11px] mb-2">إدارة احترافية للعقارات والسيارات والوكلاء المعتمدين ضمن تجربة فاخرة وآمنة.</p>
            </div>
          </div>
          <div className="border-t border-zinc-900 pt-6 text-center text-gray-500 text-[10px]">
            © {new Date().getFullYear()} شركة العقارات السورية الذهبية ليميتد. جميع الحقوق محفوظة.
          </div>
        </div>
      </footer>

    </div>
  );
}
