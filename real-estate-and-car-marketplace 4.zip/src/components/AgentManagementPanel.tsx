import { useMemo, useState } from 'react';
import { useApp } from '../context/AppContext';

export default function AgentManagementPanel() {
  const { currentUser, users, addAgent, updateAgent, deleteAgent, showToastMessage } = useApp();
  const [agentName, setAgentName] = useState('');
  const [agentPhone, setAgentPhone] = useState('');
  const [workType, setWorkType] = useState('وسيط عقاري');
  const [search, setSearch] = useState('');
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editingName, setEditingName] = useState('');
  const [editingPhone, setEditingPhone] = useState('');
  const [editingWorkType, setEditingWorkType] = useState('');
  const [submitting, setSubmitting] = useState(false);

  const isAdmin = currentUser?.role === 'admin';

  const agents = useMemo(
    () => users.filter((u) => u.is_agent && (!search.trim() || u.name.includes(search) || (u.agent_phone || '').includes(search))),
    [users, search]
  );

  const validatePhone = (phone: string) => /^0\d{9,10}$/.test(phone.trim());

  const resetEdit = () => {
    setEditingId(null);
    setEditingName('');
    setEditingPhone('');
    setEditingWorkType('');
  };

  const handleAdd = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!isAdmin) return;

    if (!agentName.trim()) {
      showToastMessage('اسم الوكيل مطلوب.', 'error');
      return;
    }
    if (!validatePhone(agentPhone)) {
      showToastMessage('رقم الهاتف غير صحيح. يجب أن يبدأ بـ 0 ويحتوي 10 أو 11 رقماً.', 'error');
      return;
    }

    try {
      setSubmitting(true);
      await addAgent({
        name: agentName.trim(),
        phone: agentPhone.trim(),
        company: workType.trim() || 'وسيط عقاري',
      });
      setAgentName('');
      setAgentPhone('');
      setWorkType('وسيط عقاري');
    } catch (error: unknown) {
      const message = error instanceof Error ? error.message : 'تعذر إضافة الوكيل حالياً.';
      showToastMessage(message, 'error');
    } finally {
      setSubmitting(false);
    }
  };

  const beginEdit = (id: string, name: string, phone: string, company?: string) => {
    setEditingId(id);
    setEditingName(name);
    setEditingPhone(phone);
    setEditingWorkType(company || 'وسيط عقاري');
  };

  const submitEdit = async (agentId: string) => {
    if (!isAdmin) return;
    if (!editingName.trim()) {
      showToastMessage('اسم الوكيل مطلوب.', 'error');
      return;
    }
    if (!validatePhone(editingPhone)) {
      showToastMessage('رقم الهاتف غير صحيح.', 'error');
      return;
    }

    try {
      setSubmitting(true);
      await updateAgent(agentId, {
        name: editingName.trim(),
        phone: editingPhone.trim(),
        company: editingWorkType.trim() || 'وسيط عقاري',
      });
      resetEdit();
    } catch (error: unknown) {
      const message = error instanceof Error ? error.message : 'تعذر تعديل الوكيل حالياً.';
      showToastMessage(message, 'error');
    } finally {
      setSubmitting(false);
    }
  };

  const removeAgent = async (agentId: string, agentNameValue: string) => {
    if (!isAdmin) return;
    if (!confirm(`هل أنت متأكد من حذف الوكيل ${agentNameValue} نهائياً؟`)) return;
    try {
      setSubmitting(true);
      await deleteAgent(agentId);
    } catch (error: unknown) {
      const message = error instanceof Error ? error.message : 'تعذر حذف الوكيل حالياً.';
      showToastMessage(message, 'error');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="bg-zinc-900 border border-[#C9A24A]/25 p-6 rounded-2xl">
        <div className="mb-4">
          <h2 className="text-xl font-black text-[#C9A24A]">👑 إدارة الوكلاء المطلقة</h2>
          <p className="text-gray-400 text-xs mt-1">فقط المدير المطلق يستطيع إضافة وتعديل وحذف الوكلاء عبر الاسم ورقم الهاتف ونوع العمل.</p>
        </div>

        {isAdmin ? (
          <form onSubmit={handleAdd} className="grid grid-cols-1 md:grid-cols-3 gap-3 text-xs">
            <input
              type="text"
              value={agentName}
              onChange={(e) => setAgentName(e.target.value)}
              placeholder="اسم الوكيل الجديد"
              className="bg-black border border-zinc-800 rounded-lg p-2.5 text-white"
            />
            <input
              type="text"
              value={agentPhone}
              onChange={(e) => setAgentPhone(e.target.value)}
              placeholder="رقم الهاتف"
              className="bg-black border border-zinc-800 rounded-lg p-2.5 text-white"
            />
            <input
              type="text"
              value={workType}
              onChange={(e) => setWorkType(e.target.value)}
              placeholder="نوع العمل: وسيط عقاري / مكتب سيارات"
              className="bg-black border border-zinc-800 rounded-lg p-2.5 text-white"
            />
            <div className="md:col-span-3">
              <button type="submit" disabled={submitting} className="w-full py-2.5 bg-[#C9A24A] text-black font-extrabold rounded-lg disabled:opacity-60">
                {submitting ? 'جارٍ التنفيذ...' : 'إضافة وكيل جديد ➕'}
              </button>
            </div>
          </form>
        ) : (
          <div className="text-center py-6 text-gray-400 text-sm bg-black/30 rounded-xl border border-zinc-800">
            أنت لست مديراً. يمكنك فقط مشاهدة الوكلاء والاتصال بهم.
          </div>
        )}
      </div>

      <div className="bg-zinc-900 border border-zinc-800 p-6 rounded-2xl space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <h3 className="text-lg font-black text-white">جدول الوكلاء</h3>
            <p className="text-gray-400 text-xs">ابحث بالاسم أو رقم الهاتف ثم راجع بيانات الوكلاء الحاليين.</p>
          </div>
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="بحث باسم الوكيل أو الهاتف"
            className="bg-black border border-zinc-800 rounded-lg p-2.5 text-white text-xs w-full sm:w-72"
          />
        </div>

        {agents.length === 0 ? (
          <div className="text-center py-10 text-gray-500 text-sm bg-black/30 rounded-xl border border-zinc-800">
            لا يوجد وكلاء مطابقون للبحث حالياً.
          </div>
        ) : (
          <div className="space-y-3">
            {agents.map((agent) => (
              <div key={agent.id} className="bg-black/40 border border-zinc-800 rounded-xl p-4 space-y-3">
                {editingId === agent.id && isAdmin ? (
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-3 text-xs">
                    <input
                      type="text"
                      value={editingName}
                      onChange={(e) => setEditingName(e.target.value)}
                      className="bg-black border border-zinc-700 rounded-lg p-2.5 text-white"
                      placeholder="اسم الوكيل"
                    />
                    <input
                      type="text"
                      value={editingPhone}
                      onChange={(e) => setEditingPhone(e.target.value)}
                      className="bg-black border border-zinc-700 rounded-lg p-2.5 text-white"
                      placeholder="رقم الهاتف"
                    />
                    <input
                      type="text"
                      value={editingWorkType}
                      onChange={(e) => setEditingWorkType(e.target.value)}
                      className="bg-black border border-zinc-700 rounded-lg p-2.5 text-white"
                      placeholder="نوع العمل"
                    />
                    <div className="md:col-span-3 flex gap-2 justify-end">
                      <button
                        type="button"
                        disabled={submitting}
                        onClick={() => submitEdit(agent.id)}
                        className="px-4 py-2 bg-[#C9A24A] text-black font-bold rounded-lg disabled:opacity-60"
                      >
                        حفظ التعديل
                      </button>
                      <button
                        type="button"
                        onClick={resetEdit}
                        className="px-4 py-2 bg-zinc-800 text-white rounded-lg"
                      >
                        إلغاء
                      </button>
                    </div>
                  </div>
                ) : (
                  <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-3">
                    <div>
                      <h4 className="font-bold text-white text-sm">{agent.name}</h4>
                      <p className="text-[11px] text-gray-400">نوع العمل: {agent.agent_company || 'وسيط عقاري'}</p>
                      <a href={`tel:${agent.agent_phone || ''}`} className="text-[11px] text-[#C9A24A]" dir="ltr">
                        {agent.agent_phone || 'بدون رقم هاتف'}
                      </a>
                    </div>
                    <div className="flex gap-2 flex-wrap">
                      <a href={`tel:${agent.agent_phone || ''}`} className="px-3 py-1.5 bg-emerald-700/20 text-emerald-400 rounded-lg text-xs">
                        اتصال
                      </a>
                      {isAdmin && (
                        <>
                          <button
                            type="button"
                            onClick={() => beginEdit(agent.id, agent.name, agent.agent_phone || '', agent.agent_company || '')}
                            className="px-3 py-1.5 bg-amber-500/15 text-amber-400 rounded-lg text-xs"
                          >
                            تعديل
                          </button>
                          <button
                            type="button"
                            onClick={() => removeAgent(agent.id, agent.name)}
                            className="px-3 py-1.5 bg-red-500/15 text-red-400 rounded-lg text-xs"
                          >
                            حذف
                          </button>
                        </>
                      )}
                    </div>
                  </div>
                )}
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
