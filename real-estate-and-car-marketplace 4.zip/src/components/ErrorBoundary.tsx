import { Component, ErrorInfo, ReactNode } from 'react';

interface Props {
  children?: ReactNode;
}

interface State {
  hasError: boolean;
  error: Error | null;
}

export class ErrorBoundary extends Component<Props, State> {
  public state: State = {
    hasError: false,
    error: null,
  };

  public static getDerivedStateFromError(error: Error): State {
    return { hasError: true, error };
  }

  public componentDidCatch(error: Error, errorInfo: ErrorInfo) {
    console.error('Uncaught error inside Golden Real Estate App:', error, errorInfo);
  }

  public render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen bg-[#0F0F0F] text-white flex flex-col items-center justify-center p-6 text-center" dir="rtl">
          <div className="h-16 w-16 rounded-full bg-red-950 flex items-center justify-center text-red-500 text-3xl mb-4">
            ⚠️
          </div>
          <h2 className="text-2xl font-black text-[#C9A24A] mb-2">عذراً، حدث خطأ غير متوقع في المنصة</h2>
          <p className="text-gray-400 text-xs max-w-md leading-relaxed mb-6">
            حدث خطأ أثناء تحميل هذه الصفحة السحابية. يرجى إعادة تحديث الصفحة أو الاتصال بالدعم الفني للمنصة الذهبية.
          </p>
          <button
            onClick={() => window.location.reload()}
            className="px-6 py-2.5 bg-[#C9A24A] text-black font-extrabold rounded-xl text-xs hover:bg-[#E5BA5A] transition-all"
          >
            إعادة تحميل المنصة الذهبية 🔄
          </button>
        </div>
      );
    }

    return this.props.children;
  }
}
export default ErrorBoundary;
