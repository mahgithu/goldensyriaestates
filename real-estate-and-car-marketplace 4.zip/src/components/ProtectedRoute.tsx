import { Navigate, Outlet } from 'react-router-dom';
import { useApp } from '../context/AppContext';

export function ProtectedRoute() {
  const { currentUser } = useApp();
  return currentUser ? <Outlet /> : <Navigate to="/login" replace />;
}

export function AdminRoute() {
  const { currentUser } = useApp();
  return currentUser?.role === 'admin' ? <Outlet /> : <Navigate to="/" replace />;
}
