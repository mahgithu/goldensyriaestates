-- ========================================================================
-- ملف تهيئة قاعدة بيانات سوبابيس (Supabase Database & Storage Setup)
-- العقارات السورية الذهبية
-- قم بنسخ هذا الكود ولصقه في قسم SQL Editor في لوحة تحكم Supabase
-- ========================================================================

-- 1. جدول الحسابات الشخصية للأعضاء والوكلاء (Profiles)
create table public.profiles (
  id uuid references auth.users on delete cascade primary key,
  name text not null,
  email text not null,
  role text not null default 'user' check (role in ('admin','user')), -- 'admin' or 'user'
  is_agent boolean default false,
  agent_company text,
  agent_phone text,
  banned boolean default false,
  created_at timestamp with time zone default timezone('utc'::text, now()) not null
);

-- تفعيل RLS على جدول الحسابات
alter table public.profiles enable row level security;

-- حذف السياسات القديمة إذا كانت موجودة
DROP POLICY IF EXISTS "الجميع يستطيع قراءة الحسابات" ON public.profiles;
DROP POLICY IF EXISTS "المستخدم يستطيع تعديل حسابه الخاص" ON public.profiles;
DROP POLICY IF EXISTS "الأدمن يستطيع التحكم بجميع الحسابات" ON public.profiles;

-- الجميع يستطيع قراءة الوكلاء فقط، وصاحب الحساب يرى حسابه، والمدير يرى الجميع
create policy "قراءة الوكلاء والملف الشخصي" on public.profiles
  for select using (
    is_agent = true
    OR auth.uid() = id
    OR exists (
      select 1 from public.profiles p where p.id = auth.uid() and p.role = 'admin'
    )
  );

-- المستخدم يستطيع تعديل ملفه الشخصي فقط
create policy "المستخدم يعدل ملفه فقط" on public.profiles
  for update using (auth.uid() = id)
  with check (auth.uid() = id);

-- المدير فقط يستطيع إضافة مستخدمين/وكلاء جدد
create policy "المدير يضيف الوكلاء" on public.profiles
  for insert with check (
    exists (
      select 1 from public.profiles p where p.id = auth.uid() and p.role = 'admin'
    )
  );

-- المدير فقط يستطيع تعديل أي ملف
create policy "المدير يعدل الحسابات" on public.profiles
  for update using (
    exists (
      select 1 from public.profiles p where p.id = auth.uid() and p.role = 'admin'
    )
  )
  with check (
    exists (
      select 1 from public.profiles p where p.id = auth.uid() and p.role = 'admin'
    )
  );

-- المدير فقط يستطيع حذف الحسابات والوكلاء
create policy "المدير يحذف الحسابات" on public.profiles
  for delete using (
    exists (
      select 1 from public.profiles p where p.id = auth.uid() and p.role = 'admin'
    )
  );

-- 2. جدول العقارات (Properties)
create table public.properties (
  id uuid default gen_random_uuid() primary key,
  title text not null,
  price bigint not null,
  price_usd bigint not null,
  city text not null,
  description text not null,
  image text not null, -- رابط الصورة في Storage
  type text not null, -- 'شقة', 'فيلا', 'أرض', 'محل'
  user_id uuid references public.profiles(id) on delete cascade not null,
  user_phone text not null,
  area integer not null,
  rooms integer default 1,
  created_at timestamp with time zone default timezone('utc'::text, now()) not null
);

-- تفعيل RLS على جدول العقارات
alter table public.properties enable row level security;

create policy "الجميع يستطيع قراءة العقارات" on public.properties
  for select using (true);

create policy "المستخدم يستطيع إضافة عقار" on public.properties
  for insert with check (auth.uid() = user_id);

create policy "المستخدم يستطيع تعديل عقاره" on public.properties
  for update using (auth.uid() = user_id or exists (
    select 1 from public.profiles where id = auth.uid() and role = 'admin'
  ));

create policy "المستخدم يستطيع حذف عقاره" on public.properties
  for delete using (auth.uid() = user_id or exists (
    select 1 from public.profiles where id = auth.uid() and role = 'admin'
  ));

-- 3. جدول السيارات (Cars)
create table public.cars (
  id uuid default gen_random_uuid() primary key,
  title text not null,
  name text not null,
  model text not null,
  price bigint not null,
  price_usd bigint not null,
  city text not null,
  description text not null,
  image text not null,
  user_id uuid references public.profiles(id) on delete cascade not null,
  user_phone text not null,
  year text not null,
  created_at timestamp with time zone default timezone('utc'::text, now()) not null
);

-- تفعيل RLS على جدول السيارات
alter table public.cars enable row level security;

create policy "الجميع يستطيع قراءة السيارات" on public.cars
  for select using (true);

create policy "المستخدم يستطيع إضافة سيارة" on public.cars
  for insert with check (auth.uid() = user_id);

create policy "المستخدم يستطيع تعديل سيارته" on public.cars
  for update using (auth.uid() = user_id or exists (
    select 1 from public.profiles where id = auth.uid() and role = 'admin'
  ));

create policy "المستخدم يستطيع حذف سيارته" on public.cars
  for delete using (auth.uid() = user_id or exists (
    select 1 from public.profiles where id = auth.uid() and role = 'admin'
  ));

-- 4. جدول الرسائل (Messages)
create table public.messages (
  id uuid default gen_random_uuid() primary key,
  name text not null,
  email text not null,
  message text not null,
  listing_title text,
  created_at timestamp with time zone default timezone('utc'::text, now()) not null
);

-- تفعيل RLS على جدول الرسائل
alter table public.messages enable row level security;

create policy "الجميع يستطيع إرسال رسالة" on public.messages
  for insert with check (true);

create policy "فقط الأدمن والمدراء يستطيعون قراءة الرسائل" on public.messages
  for select using (
    exists (
      select 1 from public.profiles where id = auth.uid() and role = 'admin'
    )
  );

create policy "فقط الأدمن يستطيع حذف الرسائل" on public.messages
  for delete using (
    exists (
      select 1 from public.profiles where id = auth.uid() and role = 'admin'
    )
  );

-- 5. جدول المفضلة (Favorites)
create table public.favorites (
  id uuid default gen_random_uuid() primary key,
  user_id uuid references public.profiles(id) on delete cascade not null,
  listing_id uuid not null,
  created_at timestamp with time zone default timezone('utc'::text, now()) not null,
  unique (user_id, listing_id)
);

-- تفعيل RLS على جدول المفضلة
alter table public.favorites enable row level security;

create policy "صاحب المفضلة يستطيع القراءة" on public.favorites
  for select using (auth.uid() = user_id);

create policy "صاحب المفضلة يستطيع الإضافة" on public.favorites
  for insert with check (auth.uid() = user_id);

create policy "صاحب المفضلة يستطيع الحذف" on public.favorites
  for delete using (auth.uid() = user_id);

-- 6. إنشاء ترتيبة تلقائية لإنشاء ملف تعريفي (Profile) فوراً بعد تسجّيل مستخدم جديد في Supabase Auth
create or replace function public.handle_new_user()
returns trigger as $$
begin
  insert into public.profiles (id, name, email, role, is_agent)
  values (
    new.id,
    coalesce(new.raw_user_meta_data->>'name', split_part(new.email, '@', 1)),
    new.email,
    case when lower(new.email) = 'admin@golden.sy' then 'admin' else 'user' end,
    false
  );
  return new;
end;
$$ language plpgsql security definer;

create or replace trigger on_auth_user_created
  after insert on auth.users
  for each row execute procedure public.handle_new_user();

-- 7. الدعم لـ Storage Buckets للصور
-- يرجى إنشاء دلو تخزين باسم `images` في تبويب Storage في سوبابيس وتفعيله كـ Public.
